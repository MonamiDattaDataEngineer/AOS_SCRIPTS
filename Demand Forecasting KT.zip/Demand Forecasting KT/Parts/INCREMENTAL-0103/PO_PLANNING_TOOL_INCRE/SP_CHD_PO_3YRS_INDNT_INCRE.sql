import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
from pyspark.sql.functions import date_sub
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

df_ph_receits1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_RECEIPTS/').select(['REC_DOC_NUM', 'COMP_FA', 'PARENT_GROUP', 'DEALER_MAP_CD', 'FROM_LOC_CD', 'REC_DOC_DATE', 'INVOICE_NUM', 'REC_DOC_TYPE', 'LOC_CD'])
df_ph_receits2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_RECEIPTS__ct/').select(['REC_DOC_NUM', 'COMP_FA', 'PARENT_GROUP', 'DEALER_MAP_CD', 'FROM_LOC_CD', 'REC_DOC_DATE', 'INVOICE_NUM', 'REC_DOC_TYPE', 'LOC_CD'])
df_ph_receits = df_ph_receits1.unionAll(df_ph_receits2)
df_ph_receits.createOrReplaceTempView('PH_RECEIPTS')

df_pd_receits1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_RECEIPTS/').select(['RECD_QTY', 'REC_DOC_TYPE', 'LOC_CD', 'COMP_FA', 'DEALER_MAP_CD', 'REC_DOC_NUM', 'PARENT_GROUP', 'REC_DOC_SRL', 'PART_NUM'])
df_pd_receits2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_RECEIPTS__ct/').select(['RECD_QTY', 'REC_DOC_TYPE', 'LOC_CD', 'COMP_FA', 'DEALER_MAP_CD', 'REC_DOC_NUM', 'PARENT_GROUP', 'REC_DOC_SRL', 'PART_NUM'])
df_pd_receits = df_pd_receits.unionAll(df_pd_receits2)
df_pd_receits.createOrReplaceTempView('PD_RECEIPTS')

df_pd_indent1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_INDENT/').select(['DEALER_MAP_CD', 'CREATED_DATE', 'STI_SRL', 'COMP_FA', 'INDENT_QTY', 'PARENT_GROUP', 'LOC_CD', 'PART_NUM', 'INDENT_NUM'])
df_pd_indent2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_INDENT__ct/').select(['DEALER_MAP_CD', 'CREATED_DATE', 'STI_SRL', 'COMP_FA', 'INDENT_QTY', 'PARENT_GROUP', 'LOC_CD', 'PART_NUM', 'INDENT_NUM'])
df_pd_indent = df_pd_indent1.unionAll(df_pd_indent2)
df_pd_indent.createOrReplaceTempView('PD_INDENT')

df_am_dealer_loc1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/').select(['REGION_CD', 'LOC_CD', 'PARENT_GROUP', 'PRINCIPAL_MAP_CD', 'DEALER_MAP_CD'])
df_am_dealer_loc2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC__ct/').select(['REGION_CD', 'LOC_CD', 'PARENT_GROUP', 'PRINCIPAL_MAP_CD', 'DEALER_MAP_CD'])
df_am_dealer_loc = df_am_dealer_loc1.unionAll(df_am_dealer_loc2)
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')

df_am_company_master1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/').select(['COMP_CODE', 'DEALER_MAP_CD', 'PARENT_GROUP'])
df_am_company_master2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER__ct/').select(['COMP_CODE', 'DEALER_MAP_CD', 'PARENT_GROUP'])
df_am_company_master = df_am_company_master1.unionAll(df_am_company_master2)
df_am_company_master.createOrReplaceTempView('AM_COMPANY_MASTER')

df_pm_part1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/').select(['DEALER_MAP_CD', 'PART_NUM', 'ROOT_PART_NUM'])
df_pm_part2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART__ct/').select(['DEALER_MAP_CD', 'PART_NUM', 'ROOT_PART_NUM'])
df_pm_part = df_pm_part1.unionAll(df_pm_part2)
df_pm_part.createOrReplaceTempView('PM_PART')

df_ph_issue1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/').select(['LOC_CD', 'PARENT_GROUP', 'REF_DOC_NUM', 'DOC_NUM', 'DOC_DATE', 'COMP_FA', 'DEALER_MAP_CD'])
df_ph_issue2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE__ct/').select(['LOC_CD', 'PARENT_GROUP', 'REF_DOC_NUM', 'DOC_NUM', 'DOC_DATE', 'COMP_FA', 'DEALER_MAP_CD'])
df_ph_issue = df_ph_issue1.unionAll(df_ph_issue2)
df_ph_issue.createOrReplaceTempView('PH_ISSUE')


df_ph_pick_list1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_PICK_LIST/').select(['LOC_CD', 'PARENT_GROUP', 'REF_DOC_NUM', 'DEALER_MAP_CD', 'PICK_NUM', 'COMP_FA'])
df_ph_pick_list2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_PICK_LIST__ct/').select(['LOC_CD', 'PARENT_GROUP', 'REF_DOC_NUM', 'DEALER_MAP_CD', 'PICK_NUM', 'COMP_FA'])
df_ph_pick_list = df_ph_pick_list1.unionAll(df_ph_pick_list2)
df_ph_pick_list.createOrReplaceTempView('PH_PICK_LIST')

df_ph_pick_list1 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_INDENT/').select(['PARENT_GROUP', 'DEALER_MAP_CD', 'INDENT_NUM', 'INDENT_STATUS', 'INDENT_TO', 'INDENT_DATE', 'LOC_CD', 'COMP_FA'])
df_ph_pick_list2 = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_INDENT__ct/').select(['PARENT_GROUP', 'DEALER_MAP_CD', 'INDENT_NUM', 'INDENT_STATUS', 'INDENT_TO', 'INDENT_DATE', 'LOC_CD', 'COMP_FA'])
df_ph_pick_list = df_ph_pick_list1.unionAll(df_ph_pick_list2)
df_ph_pick_list.createOrReplaceTempView('PH_INDENT')


df11 = spark.sql('''
select 
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
    AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    PM.ROOT_PART_NUM ROOT_PART_NUM,
    PD.RECD_QTY RECD_QTY,
    PH.REC_DOC_TYPE REC_DOC_TYPE,
    PH.PARENT_GROUP PARENT_GROUP,
    PH.COMP_FA COMP_FA,
    PH.DEALER_MAP_CD DEALER_MAP_CD,
    PH.from_loc_cd from_loc_cd,
    PH.loc_cd loc_cd,
    PH.REC_DOC_NUM REC_DOC_NUM,
    to_date(PH.REC_DOC_DATE) MRN_DATE,
    PH.INVOICE_NUM INVOICE_NUM,
    NVL(
        (select 
            first(ph1.ref_doc_num)
        from PH_ISSUE ph1
        where 
            ph1.doc_num = PH.INVOICE_NUM
            and PH1.parent_group = PH.PARENT_GROUP
            AND PH1.DEALER_MAP_CD = PH.DEALER_MAP_CD
            AND PH1.LOC_CD = PH.FROM_LOC_CD
            AND PH1.COMP_FA = PH.COMP_FA
            and to_date(ph1.doc_date) >= DATE_SUB(CURRENT_TIMESTAMP(), 120), 'NA') nvl_ref_doc_num
from 
    ph_receipts PH,
    Pd_Receipts PD,
    AM_DEALER_LOC AM,
    am_company_master MA,
    pm_part PM
where 
    PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
    AND PH.REC_DOC_TYPE = PD.REC_DOC_TYPE
    AND PH.REC_DOC_NUM = PD.REC_DOC_NUM
    AND PH.COMP_FA = PD.COMP_FA
    AND PH.LOC_CD = PD.LOC_CD
    AND PH.PARENT_GROUP = PD.PARENT_GROUP
    AND PD.REC_DOC_SRL > 0
    AND PH.DEALER_MAP_CD = AM.DEALER_MAP_CD
    AND PH.LOC_CD = AM.LOC_CD
    AND PH.PARENT_GROUP = AM.PARENT_GROUP
    AND PH.Comp_Fa = MA.Comp_Code
    and ma.parent_group = AM.parent_group
    and ma.dealer_map_cd = AM.dealer_map_cd
    and AM.principal_map_cd = 1
    AND PH.REC_DOC_TYPE IN ('SFR', 'STR', 'SGR')
    AND PM.PART_NUM = PD.PART_NUM
    AND PM.DEALER_MAP_CD = 1
    AND to_date(PH.Rec_Doc_Date) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
    AND to_date(PH.Rec_Doc_Date) < CURRENT_TIMESTAMP()
''')


df11.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/INDNT_STAGE_PATH/')
df11 = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/INDNT_STAGE_PATH/')
df11.createOrReplaceTempView('t11')

df = spark.sql(
'''
select
    'M' ROW_TRANS_TYPE,
    T2.ORDERED_PART_NUM ITEM_CODE,
    T2.WAREHOUSE_CODE WAREHOUSE_CODE,
    T2.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
    T2.indent_num ORDER_NUM,
    T2.WAREHOUSE_CODE || '-' || T2.ORDERED_PART_NUM || '-' || T2.indent_num ORDER_LINE_NUM,
    --TO_CHAR(SYSDATE, 'YYYYMMDD') || 'T' || TO_CHAR(SYSDATE, 'HH24MI') EXTRACTION_DATE,
    CONCAT(date_format(current_timestamp(),'yyyyMMdd'),'T',date_format(current_timestamp(),'HHmm')) EXTRACTION_DATE,
    --SYSDATE CREATED_DATE,
    current_timestamp() CREATED_DATE,
    T2.indent_to SUPP_CODE,
    ceil(T2.indent_qty) ORDER_QTY,
    --TO_CHAR(T2.INDENT_DATE, 'YYYYMMDD') ORDER_DATE,
    date_format(to_date(T2.INDENT_DATE), 'yyyyMMdd') as ORDER_DATE,
    ceil(SUM(T2.MRN_QTY)) RECVD_QTY,
    --TO_CHAR(max(T2.MRN_DATE), 'YYYYMMDD') RECVD_DATE
    date_format(max(T2.MRN_DATE), 'yyyyMMdd') RECVD_DATE
FROM
    (SELECT 
        pd.part_num ORDERED_PART_NUM,
        PP.ROOT_PART_NUM,
        AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
        AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
        pd.indent_num,
        ph.indent_to,
        pd.indent_qty,
        to_date(PH.INDENT_DATE) INDENT_DATE,
        NULL MRN_NUM,
        0 MRN_QTY,
        NULL MRN_DATE
        FROM 
        PH_INDENT PH,
        PD_INDENT PD,
        AM_DEALER_LOC AM,
        am_company_master ma,
        PM_PART PP
     where PH.Indent_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120))
        AND PH.INDENT_DATE < CURRENT_TIMESTAMP()
        AND PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
        AND PH.LOC_CD = PD.LOC_CD
        AND PH.PARENT_GROUP = PD.PARENT_GROUP
        AND PH.INDENT_NUM = PD.INDENT_NUM
        AND PH.COMP_FA = PD.COMP_FA
        AND PD.STI_SRL > 0
        AND PH.INDENT_STATUS NOT IN ('C','H')
        AND PH.DEALER_MAP_CD = AM.DEALER_MAP_CD
        AND PH.LOC_CD = AM.LOC_CD
        AND PH.PARENT_GROUP = AM.PARENT_GROUP
        AND AM.DEALER_MAP_CD = PH.DEALER_MAP_CD
        AND AM.LOC_CD = PH.LOC_CD
        AND AM.PRINCIPAL_MAP_CD = 1
        and ma.parent_group = AM.parent_group
        and ma.dealer_map_cd = AM.dealer_map_cd
        AND PP.PART_NUM = PD.PART_NUM
        AND PP.DEALER_MAP_CD = 1
UNION ALL ---fINE TUNED---
SELECT 
    PDT.PART_NUM ORDERED_PART_NUM,
    PP.ROOT_PART_NUM,
    T1.WAREHOUSE_CODE,
    T1.WAREHOUSE_GROUP_CODE,
    t1.indent_num,
    t1.from_loc_cd INDENT_TO,
    PDT.INDENT_QTY,
    to_date(pdt.created_date) INDENT_DATE,
    T1.REC_DOC_NUM MRN_NUM,
    T1.RECD_QTY MRN_QTY,
    T1.MRN_DATE
    FROM PD_INDENT PDT,
        PM_PART PP,
        (select 
            WAREHOUSE_CODE,
            WAREHOUSE_GROUP_CODE,
            ROOT_PART_NUM,
            RECD_QTY,
            REC_DOC_TYPE,
            PARENT_GROUP,
            COMP_FA,
            DEALER_MAP_CD,
            from_loc_cd,
            loc_cd,
            REC_DOC_NUM,
            MRN_DATE,
            INVOICE_NUM,
            NVL(
                (select 
                    FIRST(PPL.REF_DOC_NUM)
                from 
                    PH_PICK_LIST PPL
                where 
                    PPL.PICK_NUM = nvl_ref_doc_num
                    and PPL.parent_group = t11.PARENT_GROUP
                    AND PPL.DEALER_MAP_CD = t11.DEALER_MAP_CD
                    AND PPL.LOC_CD = t11.FROM_LOC_CD
                    AND PPL.COMP_FA = t11.COMP_FA), 'NA') indent_num
        from 
            t11
        ) t1
    where 
        PDT.STI_SRL > 0
        AND PDT.INDENT_NUM = t1.indent_num
        AND PDT.DEALER_MAP_CD = T1.DEALER_MAP_CD
        AND PDT.LOC_CD = T1.LOC_CD
        AND PDT.PARENT_GROUP = T1.PARENT_GROUP
        AND PDT.COMP_FA = T1.COMP_FA
        and PP.PART_NUM = PDT.PART_NUM
        AND PP.DEALER_MAP_CD = 1
        AND PP.ROOT_PART_NUM = T1.ROOT_PART_NUM) T2
GROUP BY 
        T2.ORDERED_PART_NUM,
        T2.WAREHOUSE_CODE,
        T2.WAREHOUSE_GROUP_CODE,
        T2.indent_num,
        T2.indent_to,
        T2.indent_qty,
        T2.INDENT_DATE
''')



df.show()
df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/SP_CHD_PO_3YRS_INDT_DELTA/')

