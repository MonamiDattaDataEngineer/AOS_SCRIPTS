import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


df_PT_CBO_AOS= spark.read.jdbc(url=jdbc_url4, table="(SELECT * FROM MULDMS.PT_CBO_AOS )", properties=connection_details)
DF_pm_part_selection = spark.read.jdbc(url=jdbc_url4, table="(SELECT * FROM MULDMS.pm_part_selection_temp )", properties=connection_details)


df_PD_INDENT = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_INDENT/")
df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
DF_PH_INDENT = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_INDENT/")
DF_PM_PART=spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
DF_PH_SO= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_SO/")
DF_PD_SO = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_SO/")
DF_VT_REQ = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.VT_REQ/")

df_PD_INDENT.createOrReplaceTempView("PD_INDENT")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
DF_PM_PART.createOrReplaceTempView("PM_PART")
DF_PD_SO.createOrReplaceTempView("PD_SO")
DF_VT_REQ.createOrReplaceTempView("VT_REQ")
DF_PH_INDENT.createOrReplaceTempView("PH_INDENT")
DF_PH_SO.createOrReplaceTempView("PH_SO")

##date from last 7days(currently 0 for delta)
df1 = spark.sql("""(SELECT ph.to_dealer dealer_map_cd,
                              ph.indent_to loc_cd,
                              pm.part_num,
                              SUM(CASE WHEN IFNULL(pd.indent_qty, 0) - IFNULL(pd.issued_qty, 0) > 1 THEN
                                             IFNULL(pd.indent_qty, 0) - IFNULL(pd.issued_qty, 0) - 1
                                       ELSE
                                             0 
                                    END
                                ) AS cbo,
                              
                                                                        
                              Count(ph.indent_num) pend_ord,
                              CURRENT_DATE()created_date,
                              'I' cbo_type,
                              date_format(date_trunc('day', current_timestamp),'yyyyMMdd') cbo_date 
                          FROM ph_indent     ph,
                              pd_indent     pd,
                              pm_part       pm,
                              am_dealer_loc loc
                        WHERE ph.parent_group = pd.parent_group
                          AND ph.dealer_map_cd = pd.dealer_map_cd
                          AND ph.loc_cd = pd.loc_cd
                          AND ph.comp_fa = pd.comp_fa
                          AND ph.indent_num = pd.indent_num
                          --AND ph.indent_date >= '2023-03-01'
                          --AND ph.indent_date < CURRENT_TIMESTAMP()
                          AND ph.indent_date >= DATE_SUB(CURRENT_TIMESTAMP(), 7)
                          AND ph.indent_date < CURRENT_TIMESTAMP()
                          AND pd.part_num = pm.part_num
                          AND pm.dealer_map_cd = loc.principal_map_cd
                          AND pm.principal_map_cd = loc.principal_map_cd
                          AND NVL(pd.indent_qty, 0) - NVL(pd.issued_qty, 0) > 0
                          AND NVL(ph.indent_status, 'H') = 'R'
                          AND nvl(pd.cancel_yn, 'N') <> 'Y'
                          AND loc.dealer_map_cd = ph.to_dealer
                          AND loc.loc_cd = ph.indent_to
                        GROUP BY ph.to_dealer, ph.indent_to, pm.part_num)""")
df1.show()

df2=spark.sql(""" (SELECT  ph.dealer_map_cd dealer_map_cd,
                           ph.loc_cd loc_cd,
                           pm.part_num  part_num,
                           SUM(pd.kill_qty) cbo,
                           COUNT(ph.so_num) pend_ord,
                           CURRENT_TIMESTAMP() created_date,
                           'C' cbo_type,
                           date_format(date_trunc('day', current_timestamp),'yyyyMMdd') cbo_date
                    FROM ph_so         ph,
                            pd_so         pd,
                            pm_part       pm,
                            am_dealer_loc loc
                      WHERE ph.so_date >= DATE_SUB(CURRENT_TIMESTAMP(), 7)
                        AND ph.so_date < CURRENT_TIMESTAMP()
                       -- WHERE ph.so_date >= '2023-03-01'
                       -- AND ph.so_date < CURRENT_TIMESTAMP()   
                        AND ph.parent_group = pd.parent_group
                        AND ph.dealer_map_cd = pd.dealer_map_cd
                        AND ph.loc_cd = pd.loc_cd
                        AND ph.comp_fa = pd.comp_fa
                        AND ph.so_num = pd.so_num
                        AND pd.part_num = pm.part_num
                        AND pm.dealer_map_cd = loc.principal_map_cd
                        AND pm.principal_map_cd = loc.principal_map_cd
                        AND NVL(pd.kill_qty, 0) > 0
                        AND nvl(pd.cancel_yn, 'N') <> 'Y'
                        AND loc.dealer_map_cd = ph.dealer_map_cd
                        AND loc.loc_cd = ph.loc_cd                    
                      GROUP BY ph.dealer_map_cd, ph.loc_cd, pm.part_num)""")
df2.show()


                    

df3=spark.sql("""(SELECT vt.dealer_map_cd dealer_map_cd,
                         vt.loc_cd loc_cd,
                         pm.Part_Num,
                         SUM(NVL(vt.req_qty, 0) - NVL(vt.iss_qty, 0)) cbo,
                         Count(vt.part_num) pend_ord,
                         CURRENT_TIMESTAMP created_date,
                         'R' cbo_type,
                         date_format(date_trunc('day', current_timestamp),'yyyyMMdd') cbo_date
                  FROM vt_req vt, pm_part pm, am_dealer_loc loc
                     WHERE vt.req_date >= DATE_SUB(CURRENT_TIMESTAMP(), 7)
                       AND vt.req_date < CURRENT_TIMESTAMP()
                       AND NVL(vt.req_qty, 0) - NVL(vt.iss_qty, 0) > 0
                       AND NVL(vt.req_status, 'O') != 'C'
                       AND vt.part_num = pm.part_num
                       AND pm.dealer_map_cd = loc.principal_map_cd
                       AND pm.principal_map_cd = loc.principal_map_cd
                       AND loc.dealer_map_cd = vt.dealer_map_cd
                       AND loc.loc_cd = vt.loc_cd
                     GROUP BY vt.dealer_map_cd, vt.loc_cd, pm.part_num)""")
df_final=df1.unionAll(df2).unionAll(df3)    
df_final.show()

##df_result=df1.write.format('parquet').mode('append').save('s3://msil-aos-processed/DELTA/PT_CBO_AOS/')
##df_result=df2.write.format('parquet').mode('append').save('s3://msil-aos-processed/DELTA/PT_CBO_AOS/')
##df_result=df3.write.format('parquet').mode('append').save('s3://msil-aos-processed/DELTA/PT_CBO_AOS/')

df_final.write.mode('overwrite').save('s3://msil-aos-processed/DELTA/PT_CBO_AOS/')                       



df.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/PO_PLANNING_TOOL_TOG_DELTA/")
