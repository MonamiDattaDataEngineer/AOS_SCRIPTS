inport sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import date_sub
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }

print(" Reading data from RDS Instance.")

spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

from pyspark.sql.functions import col
from pyspark.sql.functions import date_sub

from pyspark.sql.functions import current_timestamp


df_PH_INDENT1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_INDENT/").filter(col('INDENT_DATE')>date_sub(current_timestamp(), 120))
df_PH_INDENT2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_INDENT__ct/").filter(col('INDENT_DATE')>date_sub(current_timestamp(), 120))
df_PH_INDENT = df_PH_INDENT1.unionAll(df_PH_INDENT2).filter(col('INDENT_DATE')>date_sub(current_timestamp(), 120)).distinct()

df_PD_INDENT1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_INDENT/").filter(col('CANCELED_DATE')>date_sub(current_timestamp(), 120))
df_PD_INDENT2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_INDENT__ct/").filter(col('CANCELED_DATE')>date_sub(current_timestamp(), 120))
df_PD_INDENT = df_PD_INDENT1.unionAll(df_PD_INDENT2).filter(col('CANCELED_DATE')>date_sub(current_timestamp(), 120)).distinct()

df_AM_DEALER_LOC1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
df_AM_DEALER_LOC2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC__ct/")
df_AM_DEALER_LOC = df_AM_DEALER_LOC1.unionAll(df_AM_DEALER_LOC2)


df_am_company_master1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/")
df_am_company_master2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER__ct/")
df_am_company_master = df_am_company_master1.unionAll(df_am_company_master2)

DF_PH_ISSUE1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/").filter(col('DOC_DATE')>date_sub(current_timestamp(), 120))
DF_PH_ISSUE2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE__ct/").filter(col('DOC_DATE')>date_sub(current_timestamp(), 120))
DF_PH_ISSUE = DF_PH_ISSUE1.unionAll(DF_PH_ISSUE2).filter(col('DOC_DATE')>date_sub(current_timestamp(), 120)).distinct()

DF_pm_part1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
DF_pm_part2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART__ct/")
DF_pm_part = DF_pm_part1.unionAll(DF_pm_part2)

DF_PD_ISSUE1= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_ISSUE/")
DF_PD_ISSUE2= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_ISSUE__ct/")
DF_PD_ISSUE = DF_PD_ISSUE1.unionAll(DF_PD_ISSUE2)

DF_ph_pick_list1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_PICK_LIST/")
DF_ph_pick_list2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_PICK_LIST__ct/")
DF_ph_pick_list = DF_ph_pick_list1.unionAll(DF_ph_pick_list2)


df_PH_INDENT.createOrReplaceTempView("PH_INDENT")
df_PD_INDENT.createOrReplaceTempView("PD_INDENT")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
df_am_company_master.createOrReplaceTempView("am_company_master")
DF_PH_ISSUE.createOrReplaceTempView("PH_ISSUE")
DF_PD_ISSUE.createOrReplaceTempView("PD_ISSUE")
DF_pm_part.createOrReplaceTempView("pm_part")
DF_ph_pick_list.createOrReplaceTempView("ph_pick_list")

df1 = spark.sql("""(Select Raw_Transaction_Type,
             Item_Code,
             Prefix,
             Warehouse_code,
             Warehouse_Grp_Cd,
             Sales_Order_Num,
             Sales_Ord_Line_Num,
             Extraction_date,
             sum(Ordered_Qty - return_qty - Cancel_Qty) Ordered_quantity,
             sum(Sale_Qty - return_qty) Supplied_quantity,
             Demand_Date,
             Customer_Code,
             Use_For_Forcasting,
             Use_For_Service_Level,
             Use_For_Classification,
             Stock_demand_date,
             Sales_Type,
             Job_Card_Number,
             max(Job_Card_Status) Job_Card_Status,
             Party_Type,
             Service_Type,
             Use_For_Sales_Value_KPI,
             Demand_Stream,
             Direct_Demand,
             DATE_FORMAT(Order_Date, 'dd-MM-yyyy') Order_Date,
             CURRENT_TIMESTAMP() Created_date
        from (SELECT 'M' Raw_Transaction_Type,
                     PD.PART_NUM Item_Code,
                     '' Prefix,
                     AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                     AM.LOC_CD Warehouse_code,
                     AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                     PD.INDENT_NUM Sales_Order_Num,
                     AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                     PD.INDENT_NUM || PD.PART_NUM ||
                     DATE_FORMAT(PH.Indent_date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                     DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                     PD.Indent_Qty Ordered_Qty,
                     0 Sale_Qty,
                     0 Cancel_Qty,
                     0 Return_Qty,
                     DATE_FORMAT(PH.Indent_date, 'yyyyMMdd') Demand_Date,
                     '' Customer_Code,
                     'N' Use_For_Forcasting,
                     'N' Use_For_Service_Level,
                     'N' Use_For_Classification,
                     '' Stock_demand_date,
                     'Indent' Sales_Type,
                     '' Job_Card_Number,
                     '' Job_Card_Status,
                     '' Party_Type,
                     '' Service_Type,
                     'N' Use_For_Sales_Value_KPI,
                     '' Demand_Stream,
                     '' Direct_Demand,
                     '' Order_date
                FROM PH_INDENT         PH,
                     PD_INDENT         PD,
                     AM_DEALER_LOC     AM,
                     am_company_master ma 
               WHERE PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
                 AND PH.LOC_CD = PD.LOC_CD
                 AND PH.PARENT_GROUP = PD.PARENT_GROUP
                 AND PH.Indent_Num = PD.Indent_Num
                 AND PH.COMP_FA = PD.COMP_FA
                 AND PH.Indent_to = AM.LOC_CD
                 AND PH.To_Dealer = AM.DEALER_MAP_CD
                 AND PH.PARENT_GROUP = AM.PARENT_GROUP
                 and ma.parent_group = AM.parent_group
                 and ma.dealer_map_cd = AM.dealer_map_cd
                 and AM.principal_map_cd = 1
                 and PH.Indent_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                 and PH.Indent_date < CURRENT_TIMESTAMP()
              
              UNION ALL
              select distinct  'M' Raw_Transaction_Type,
                              pdo.part_num Item_Code,
                              '' Prefix,
                              AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                              AM.LOC_CD Warehouse_code,
                              AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                              PSO.Indent_num Sales_Order_Num,
                              AM.PARENT_GROUP || AM.Dealer_Map_Cd ||
                              AM.LOC_CD || PSO.INDENT_NUM || PDO.PART_NUM ||
                              DATE_FORMAT(PSO.Indent_date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                              DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                              0 Ordered_Qty,
                              (pd.bill_qty) Sale_Qty,
                              0 Cancel_Qty,
                              0 Return_qty,
                              DATE_FORMAT(PSO.Indent_date, 'yyyyMMdd') Demand_Date,
                              '' Customer_Code,
                              'N' Use_For_Forcasting,
                              'N' Use_For_Service_Level,
                              'N' Use_For_Classification,
                              '' Stock_demand_date,
                              'Indent' Sales_Type,
                              '' Job_Card_Number,
                              DATE_FORMAT(ph.doc_date, 'yyyyMMdd') Job_Card_Status,
                              NVL(PH.Party_Type,'') Party_Type,
                              '' Service_Type,
                              'N' Use_For_Sales_Value_KPI,
                              '' Demand_Stream,
                              '' Direct_Demand,
                              '' Order_date
                from PH_ISSUE          ph,
                     PD_ISSUE          pd,
                     ph_pick_list      ppl,
                     am_dealer_loc     am,
                     am_company_master ma,
                     PH_INDENT         pso,
                     PD_INDENT         pdo,
                     pm_part           pm,
                     pm_part           pm1
               where Ph.DOC_TYPE IN ('SFI')
                 AND ph.parent_group = AM.parent_group
                 and ph.dealer_map_cd = AM.dealer_map_cd
                 and ph.loc_cd = AM.loc_cd
                 and ph.comp_fa = ma.comp_code
                 and ph.doc_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                 and ph.doc_date < CURRENT_TIMESTAMP()
                 and PSO.Indent_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                 and PSO.Indent_date < CURRENT_TIMESTAMP()                  
                 and pd.parent_group = ph.parent_group
                 and pd.dealer_map_cd = ph.dealer_map_cd
                 and pd.loc_cd = ph.loc_cd
                 and pd.comp_fa = ph.comp_fa
                 and pd.doc_type = ph.doc_type
                 and pd.doc_num = ph.doc_num
                 and pd.srl_num >= 0
                 and ma.parent_group = AM.parent_group
                 and ma.dealer_map_cd = AM.dealer_map_cd
                 and AM.principal_map_cd = 1
                 and ppl.parent_group = ph.parent_group
                 and ppl.dealer_map_cd = ph.dealer_map_cd
                 and ppl.loc_cd = ph.loc_cd
                 and ppl.comp_fa = ph.comp_fa
                 and ppl.pick_num = ph.ref_doc_num
                 and pso.parent_group = ppl.parent_group
                 and pso.to_dealer = ppl.dealer_map_cd
                 and pso.indent_to = ppl.loc_cd
                 and pso.comp_fa = ppl.comp_fa
                 and pso.indent_num = ppl.ref_doc_num
                 AND PSO.Dealer_Map_Cd = PDO.DEALER_MAP_CD
                 AND PSO.Loc_Cd = PDO.LOC_CD
                 AND PSO.PARENT_GROUP = PDO.PARENT_GROUP
                 and pso.indent_num = pdo.indent_num
                 and ph.to_loc_cd = pso.loc_cd 
                 AND PM.PART_NUM = pd.PART_NUM
                 AND PM.DEALER_MAP_CD = 1
                 AND PM1.PART_NUM = pdo.PART_NUM
                 AND PM1.DEALER_MAP_CD = 1
                 and pm.root_part_num = pm1.root_part_num
                 and pso.comp_fa = pdo.comp_fa
              
              UNION ALL
              
              SELECT 'M' Raw_Transaction_Type,
                     PD.PART_NUM Item_Code,
                     '' Prefix,
                     AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                     AM.LOC_CD Warehouse_code,
                     AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                     PD.Indent_num Sales_Order_Num,
                     AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                     PD.INDENT_NUM || PD.PART_NUM ||
                     DATE_FORMAT(PH.Indent_date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                     DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                     0 Ordered_Qty,
                     0 Sale_Qty,
                     CASE when PD.Cancel_qty>pd.indent_qty then
                      pd.indent_qty
                     else
                      pd.cancel_qty
                      end as Cancel_QTY,
                     0 Return_qty,
                     DATE_FORMAT(PH.INDENT_DATE, 'yyyyMMdd') Demand_Date,
                     '' Customer_Code,
                     'N' Use_For_Forcasting,
                     'N' Use_For_Service_Level,
                     'N' Use_For_Classification,
                     '' Stock_demand_date,
                     'Indent' Sales_Type,
                     '' Job_Card_Number,
                     '' Job_Card_Status,
                     '' Party_Type,
                     '' Service_Type,
                     'N' Use_For_Sales_Value_KPI,
                     '' Demand_Stream,
                     '' Direct_Demand,
                     '' Order_date
                FROM PH_INDENT         PH,
                     PD_INDENT         PD,
                     AM_DEALER_LOC     AM,
                     am_company_master ma,
                     PM_PART           PM
               WHERE PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
                 AND PH.LOC_CD = PD.LOC_CD
                 AND PH.PARENT_GROUP = PD.PARENT_GROUP
                 AND PH.indent_num = PD.Indent_Num
                 AND PH.COMP_FA = PD.COMP_FA
                 and PM.Part_Num = PD.PART_NUM
                 AND PH.Indent_to = AM.LOC_CD
                 AND PH.To_Dealer = AM.DEALER_MAP_CD
                 AND PH.PARENT_GROUP = AM.PARENT_GROUP
                 and ma.parent_group = AM.parent_group
                 and ma.dealer_map_cd = AM.dealer_map_cd
                 and AM.principal_map_cd = 1
                 AND PM.PART_NUM = pd.PART_NUM
                 AND PM.DEALER_MAP_CD = 1                    
                 and PD.canceled_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                 and PD.canceled_date < CURRENT_TIMESTAMP()
                 and PH.Indent_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                 and PH.Indent_date < CURRENT_TIMESTAMP()
                 AND pd.cancel_yn = 'Y'
              
              )
       group by Raw_Transaction_Type,
                Item_Code,
                Warehouse_code,
                Warehouse_Grp_Cd,
                Sales_Order_Num,
                Sales_Ord_Line_Num,
                Extraction_date,
                Customer_Code,
                Use_For_Forcasting,
                Use_For_Service_Level,
                Use_For_Classification,
                Sales_Type,
                Job_Card_Number,               
                Party_Type,
                Service_Type,
                Use_For_Sales_Value_KPI,
                Demand_Stream,
                Direct_Demand,
                Order_Date,
                Stock_demand_date,
                Demand_Date,
                Prefix)""")
                
                
df1.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/SP_TRAN_DEMAND_INDENT/")               