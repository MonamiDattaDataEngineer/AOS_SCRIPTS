import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
from pyspark.sql.functions import date_sub

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }

print(" Reading data from RDS Instance.")

spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead","CORRECTED")

from pyspark.sql.functions import col
from pyspark.sql.functions import date_sub

from pyspark.sql.functions import current_timestamp


df_VT_REQ1 = spark.read.parquet("s3://msil-aos-raw/data20230403/VT_REQ/").filter(col('REQ_DATE')>date_sub(current_timestamp(), 120))
df_VT_REQ2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.VT_REQ__ct/").filter(col('REQ_DATE')>date_sub(current_timestamp(), 120))
df_VT_REQ = df_VT_REQ1.unionAll(df_VT_REQ2).distinct()


df_VH_RO1 = spark.read.parquet("s3://msil-aos-raw/data20230403/VH_RO/")
df_VH_RO2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.VH_RO__ct/")
df_VH_RO = df_VH_RO1.unionAll(df_VH_RO2).distinct()

df_AM_DEALER_LOC1 = spark.read.parquet("s3://msil-aos-raw/data20230403/AM_DEALER_LOC/")
df_AM_DEALER_LOC2 = spark.read.parquet("s3://msil-aos-raw/data20230403/AM_DEALER_LOC__ct/")
df_AM_DEALER_LOC = df_AM_DEALER_LOC.unionAll(df_AM_DEALER_LOC2).distinct()

df_am_company_master1 = spark.read.parquet("s3://msil-aos-raw/data20230403/AM_COMPANY_MASTER/")
df_am_company_master2 = spark.read.parquet("s3://msil-aos-raw/data20230403/AM_COMPANY_MASTER__ct/")
df_am_company_master = df_am_company_master1.unionAll(df_am_company_master2).distinct()

DF_PH_ISSUE1 = spark.read.parquet("s3://msil-aos-raw/data20230403/PH_ISSUE/").filter(col('INDENT_DATE')>date_sub(current_timestamp(), 120))
DF_PH_ISSUE2 = spark.read.parquet("s3://msil-aos-raw/data20230403/PH_ISSUE__ct/").filter(col('INDENT_DATE')>date_sub(current_timestamp(), 120))
DF_PH_ISSUE = DF_PH_ISSUE1.unionAll(DF_PH_ISSUE2).distinct()

DF_pm_part1 = spark.read.parquet("s3://msil-aos-raw/data20230403/PM_PART/")
DF_pm_part2 = spark.read.parquet("s3://msil-aos-raw/data20230403/PM_PART__ct/")
DF_pm_part1 = DF_pm_part1.unionAll(DF_pm_part2).distinct()

DF_PD_ISSUE1= spark.read.parquet("s3://msil-aos-raw/data20230403/PD_ISSUE/")
DF_PD_ISSUE2= spark.read.parquet("s3://msil-aos-raw/data20230403/PD_ISSUE__ct/")
DF_PD_ISSUE = DF_PD_ISSUE1.unionAll(DF_PD_ISSUE2).distinct()



df_VT_REQ.createOrReplaceTempView("VT_REQ")
df_VH_RO.createOrReplaceTempView("VH_RO")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
df_am_company_master.createOrReplaceTempView("am_company_master")
DF_PH_ISSUE.createOrReplaceTempView("PH_ISSUE")
DF_PD_ISSUE.createOrReplaceTempView("PD_ISSUE")
DF_pm_part.createOrReplaceTempView("pm_part")

df1 = spark.sql("""(Select Raw_Transaction_Type,
                 Item_Code,
                 Prefix,
                 Warehouse_code,
                 Warehouse_Grp_Cd,
                 Sales_Order_Num,
                 Sales_Ord_Line_Num,
                 Extraction_date,                 
                 sum(Ordered_Qty - return_qty - Cancel_Qty) Ordered_quantity,
                 sum(Sale_Qty - return_qty) Supplied_quantity,
                 max(Demand_Date) Demand_Date,
                 Customer_Code,
                 Use_For_Forcasting,
                 Use_For_Service_Level,
                 Use_For_Classification,
                 Stock_demand_date,
                 Sales_Type,
                 Job_Card_Number,
                 Job_Card_Status,
                 Party_Type,
                 Service_Type,
                 Use_For_Sales_Value_KPI,
                 Demand_Stream,
                 Direct_Demand,
                 Order_Date,
				 CURRENT_TIMESTAMP() Created_date
            from (SELECT
                   'M' Raw_Transaction_Type,
                   VT.PART_NUM Item_Code,
                   '' Prefix,
                   AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                   AM.LOC_CD Warehouse_code,
                   AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                   VT.Req_Num Sales_Order_Num,
                   AM.PARENT_GROUP||AM.Dealer_Map_Cd||AM.LOC_CD||VT.Req_Num||VT.PART_NUM||'R' Sales_Ord_Line_Num, 
                   DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,                  
                   nvl(VT.Req_Qty, 0) Ordered_Qty,
                   0 Sale_Qty,
                   0 Cancel_Qty,
                   0 Return_Qty,
                   '' Demand_Date,
                   '' Customer_Code,
                  'N' Use_For_Forcasting,
                   case
                     when vh.ro_status = 20 then
                      'N'
                     else
                      ''
                   end as Use_For_Service_Level,
                    'N 'Use_For_Classification,
                   '' Stock_demand_date,
                   'Workshop' Sales_Type,
                   Vt.Ro_Num Job_Card_Number,
                   vh.ro_status Job_Card_Status,
                   'CU' Party_Type,
                   vh.rcateg_cd Service_Type,
                   'N' Use_For_Sales_Value_KPI,
                   '' Demand_Stream,
                   '' Direct_Demand,
                   DATE_FORMAT(vt.req_date, 'dd-MM-yyyy') Order_date                   
                    FROM VT_REQ       VT,
                         VH_RO        vh,
                         AM_DEALER_LOC     AM,
                         am_company_master ma
                   WHERE VH.DEALER_MAP_CD = AM.DEALER_MAP_CD
                     AND VH.LOC_CD = AM.LOC_CD
                     AND VH.PARENT_GROUP = AM.PARENT_GROUP
                     and vh.comp_fa = ma.comp_code
                     and DATE(VT.REQ_DATE) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                     and DATE(VT.REQ_DATE) < CURRENT_TIMESTAMP()
                     and vt.dealer_map_cd = vh.dealer_map_cd
                     and vt.parent_group = vh.parent_group
                     and vt.loc_cd = vh.loc_cd
                     and vt.comp_fa = vh.comp_fa
                     and vt.ro_num = vh.ro_num
                     and ma.parent_group = AM.parent_group
                     and ma.dealer_map_cd = AM.dealer_map_cd
                     and AM.principal_map_cd = 1
                     
                     

                  UNION ALL

                  SELECT 
                   'M' Raw_Transaction_Type,
                   PD.PART_NUM Item_Code,
                   '' Prefix,
                   AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                   AM.LOC_CD Warehouse_code,
                   AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                   vt.req_num Sales_Order_Num,
                   AM.PARENT_GROUP||AM.Dealer_Map_Cd||AM.LOC_CD||VT.Req_Num||PD.PART_NUM||'R' Sales_Ord_Line_Num, 
                   DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,                    
                   0 Ordered_qty,
                   nvl(pd.bill_qty, 0) Sale_Qty,
                   0 Cancel_Qty,
                   nvl(PD.ret_qty, 0) Return_qty,
                   DATE_FORMAT(PH.doc_date, 'yyyyMMdd') Demand_Date,
                   '' Customer_Code,
                  'N' Use_For_Forcasting,
                   case
                     when vh.ro_status = 20 then
                      'N'
                     else
                      ''
                   end as Use_For_Service_Level,
                    'N 'Use_For_Classification,
                   '' Stock_demand_date,
                   'Workshop' Sales_Type,
                   vt.ro_num Job_Card_Number,
                   vh.ro_status Job_Card_Status,
                   'CU' Party_Type,
                   vh.rcateg_cd Service_Type,
                   'N' Use_For_Sales_Value_KPI,
                   '' Demand_Stream,
                   '' Direct_Demand,
                   DATE_FORMAT(vt.req_date, 'dd-MM-yyyy') Order_date                   
                    from PH_ISSUE      ph,
                         PD_ISSUE      pd,
                         am_dealer_loc     AM,
                         pm_part           pm,
                         pm_part           pm1,
                         am_company_master ma,
                         VT_REQ       VT,
                         VH_RO        VH
                   where Ph.DOC_TYPE IN ('SRI')
                     and ph.parent_group = AM.parent_group
                     and ph.dealer_map_cd = AM.dealer_map_cd
                     and ph.loc_cd = AM.loc_cd
                     and ph.comp_fa = ma.comp_code
                     and DATE(ph.doc_date) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                     and DATE(ph.doc_date) < CURRENT_TIMESTAMP()
                     and DATE(VT.REQ_DATE) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                     and DATE(VT.REQ_DATE) < CURRENT_TIMESTAMP()
                     and pd.parent_group = ph.parent_group
                     and pd.dealer_map_cd = ph.dealer_map_cd
                     and pd.loc_cd = ph.loc_cd
                     and pd.comp_fa = ph.comp_fa
                     and pd.doc_type = ph.doc_type
                     and pd.doc_num = ph.doc_num
                     and pd.srl_num >= 0
                     and vt.parent_group = ph.parent_group
                     and vt.dealer_map_cd = ph.dealer_map_cd
                     and vt.loc_cd = ph.loc_cd
                     and vt.comp_fa = ph.comp_fa
                     and vt.part_num = pm.part_num
                     AND PM.PART_NUM = pd.PART_NUM
                     AND PM.DEALER_MAP_CD = 1
                     AND PM1.PART_NUM = vt.part_num
                     AND PM1.DEALER_MAP_CD = 1
                     and vt.req_num = pd.ref_doc_num
                     and ma.parent_group = AM.parent_group
                     and ma.dealer_map_cd = AM.dealer_map_cd
                     and AM.principal_map_cd = 1
                     and vt.dealer_map_cd = vh.dealer_map_cd
                     and vt.parent_group = vh.parent_group
                     and vt.loc_cd = vh.loc_cd
                     and vt.comp_fa = vh.comp_fa
                     and vt.ro_num = vh.ro_num
                     
                     
                  UNION ALL
                  SELECT 
                   'M' Raw_Transaction_Type,
                   VT.PART_NUM Item_Code,
                   '' Prefix,
                   AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                   AM.LOC_CD Warehouse_code,
                   AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                   VT.Req_Num Sales_Order_Num,
                   AM.PARENT_GROUP||AM.Dealer_Map_Cd||AM.LOC_CD||VT.Req_Num||VT.PART_NUM||'R' Sales_Ord_Line_Num, 
                   DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,                   
                   0 Ordered_Qty,
                   0 Sale_Qty,
                   nvl((vt.req_qty - vt.iss_qty), 0) Cancel_Qty,
                   0 Return_Qty,
                   '' Demand_Date,
                   '' Customer_Code,
                  'N' Use_For_Forcasting,
                   case
                     when vh.ro_status = 20 then
                      'N'
                     else
                      ''
                   end as Use_For_Service_Level,
                    'N 'Use_For_Classification,
                   '' Stock_demand_date,
                   'Workshop' Sales_Type,
                   Vt.Ro_Num Job_Card_Number,
                   vh.ro_status Job_Card_Status,
                   'CU' Party_Type,
                   vh.rcateg_cd Service_Type,
                   'N' Use_For_Sales_Value_KPI,
                   '' Demand_Stream,
                   '' Direct_Demand,
                   DATE_FORMAT(vt.req_date, 'dd-MM-yyyy') Order_date                  
                    FROM VT_REQ       VT,
                         VH_RO        vh,
                         AM_DEALER_LOC     AM,
                         am_company_master ma
                   WHERE VT.DEALER_MAP_CD = AM.DEALER_MAP_CD
                     AND vt.LOC_CD = AM.LOC_CD
                     AND vt.PARENT_GROUP = AM.PARENT_GROUP
                     and vt.comp_fa = ma.comp_code
                     and ma.parent_group = AM.parent_group
                     and ma.dealer_map_cd = AM.dealer_map_cd
                     and AM.principal_map_cd = 1
                     and DATE(VT.MODIFIED_DATE) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                     and DATE(VT.MODIFIED_DATE) < CURRENT_TIMESTAMP()
                     and vt.req_status = 'C'
                     and vt.dealer_map_cd = vh.dealer_map_cd
                     and vt.parent_group = vh.parent_group
                     and vt.loc_cd = vh.loc_cd
                     and vt.comp_fa = vh.comp_fa
                     and vt.ro_num = vh.ro_num
                     
                     

                  )
           group by Raw_Transaction_Type,
                    Item_Code,
                    Prefix,
                    Warehouse_code,
                    Warehouse_Grp_Cd,
                    Sales_Order_Num,
                    Sales_Ord_Line_Num,
                    Extraction_date,                    
                    Customer_Code,
                    Use_For_Forcasting,
                    Use_For_Service_Level,
                    Use_For_Classification,
                    Stock_demand_date,
                    Sales_Type,
                    Job_Card_Number,
                    Job_Card_Status,
                    Party_Type,
                    Service_Type,
                    Use_For_Sales_Value_KPI,
                    Demand_Stream,
                    Direct_Demand,
                    Order_Date

          UNION ALL
          Select Raw_Transaction_Type,
                 Item_Code,
                 Prefix,
                 Warehouse_code,
                 Warehouse_Grp_Cd,
                 Sales_Order_Num,
                 Sales_Ord_Line_Num,
                 Extraction_date,                 
                 sum(Sale_Qty - return_qty) Ordered_quantity,
                 sum(Sale_Qty - return_qty) Supplied_quantity,
                 max(Demand_Date),
                 Customer_Code,
                 Use_For_Forcasting,
                 Use_For_Service_Level,
                 Use_For_Classification,
                 Stock_demand_date,
                 Sales_Type,
                 Job_Card_Number,
                 Job_Card_Status,
                 Party_Type,
                 Service_Type,
                 Use_For_Sales_Value_KPI,
                 Demand_Stream,
                 Direct_Demand,
                 Order_date,
				 CURRENT_TIMESTAMP() Created_date
            from (SELECT 
                   'M' Raw_Transaction_Type,
                   vt.part_num Item_Code,
                   '' Prefix,
                   AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                   AM.LOC_CD Warehouse_code,
                   AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                   vt.req_num Sales_Order_Num,
                   AM.PARENT_GROUP||AM.Dealer_Map_Cd||AM.LOC_CD||VT.Req_Num||VT.PART_NUM||'F' Sales_Ord_Line_Num, 
                   DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,                 
                   0 Ordered_qty,
                   pd.bill_qty Sale_Qty,
                   0 Cancel_Qty,
                   nvl(PD.ret_qty, 0) Return_qty,
                   --PD.Ret_Qty Return_Qty,
                   DATE_FORMAT(PH.doc_date, 'yyyyMMdd') Demand_Date,
                   '' Customer_Code,
                   case
                     when vh.ro_status = 40 then
                      ''
                     else
                      'N'
                   end as Use_For_Forcasting,
                   'N' Use_For_Service_Level,
                   case
                     when vh.ro_status = 40 then
                      ''
                     else
                      'N'
                   end as Use_For_Classification,
                   '' Stock_demand_date,
                   'Workshop' Sales_Type,
                   vt.ro_num Job_Card_Number,
                   vh.ro_status Job_Card_Status,
                   'CU' Party_Type,
                   vh.rcateg_cd Service_Type,
                   '' Use_For_Sales_Value_KPI,
                   '' Demand_Stream,
                   '' Direct_Demand,
                   DATE_FORMAT(vt.req_date, 'dd-MM-yyyy') Order_date                  
                    from PH_ISSUE      ph,
                         PD_ISSUE      pd,
                         am_dealer_loc     AM,
                         pm_part           pm,
                         pm_part           pm1,
                         am_company_master ma,
                         VT_REQ       VT,
                         VH_RO        VH
                   where Ph.DOC_TYPE IN ('SRI')
                     AND ph.parent_group = AM.parent_group
                     and ph.dealer_map_cd = AM.dealer_map_cd
                     and ph.loc_cd = AM.loc_cd
                     and ph.comp_fa = ma.comp_code
                     and DATE(ph.doc_date) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                     and DATE(ph.doc_date) < CURRENT_TIMESTAMP()
                     and pd.parent_group = ph.parent_group
                     and pd.dealer_map_cd = ph.dealer_map_cd
                     and pd.loc_cd = ph.loc_cd
                     and pd.comp_fa = ph.comp_fa
                     and pd.doc_type = ph.doc_type
                     and pd.doc_num = ph.doc_num
                     and pd.srl_num >= 0
                     and vt.parent_group = ph.parent_group
                     and vt.dealer_map_cd = ph.dealer_map_cd
                     and vt.loc_cd = ph.loc_cd
                     and vt.comp_fa = ph.comp_fa
                     and vt.part_num = pm.part_num
                     AND PM.PART_NUM = pd.PART_NUM
                     AND PM.DEALER_MAP_CD = 1
                     AND PM1.PART_NUM = vt.part_num
                     AND PM1.DEALER_MAP_CD = 1
                     and vt.req_num = pd.ref_doc_num
                     and ma.parent_group = AM.parent_group
                     and ma.dealer_map_cd = AM.dealer_map_cd
                     and AM.principal_map_cd = 1
                     and vt.dealer_map_cd = vh.dealer_map_cd
                     and vt.parent_group = vh.parent_group
                     and vt.loc_cd = vh.loc_cd
                     and vt.comp_fa = vh.comp_fa
                     and vt.ro_num = vh.ro_num
                    
                     )
           group by Raw_Transaction_Type,
                    Item_Code,
                    Prefix,
                    Warehouse_code,
                    Warehouse_Grp_Cd,
                    Sales_Order_Num,
                    Sales_Ord_Line_Num,
                    Extraction_date,                   
                    Customer_Code,
                    Use_For_Forcasting,
                    Use_For_Service_Level,
                    Use_For_Classification,
                    Stock_demand_date,
                    Sales_Type,
                    Job_Card_Number,
                    Job_Card_Status,
                    Party_Type,
                    Service_Type,
                    Use_For_Sales_Value_KPI,
                    Demand_Stream,
                    Direct_Demand,
                    Order_Date)""")
                    
                    
df1.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/SP_TRAN_DEMAND_WORKSHOP/")