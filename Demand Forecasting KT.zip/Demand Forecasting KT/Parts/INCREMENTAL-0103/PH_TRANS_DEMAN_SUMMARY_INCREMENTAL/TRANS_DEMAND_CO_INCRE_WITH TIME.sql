
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta
from pyspark.sql.functions import date_sub
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
df_am_company_master = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/")
DF_PH_ISSUE = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/")
DF_pm_part = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
df_PH_SO= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_SO/")
df_PD_SO= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_SO/")
DF_PD_ISSUE= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_ISSUE/")


df_PH_SO.createOrReplaceTempView("PH_SO")
df_PD_SO.createOrReplaceTempView("PD_SO")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
df_am_company_master.createOrReplaceTempView("am_company_master")
DF_PH_ISSUE.createOrReplaceTempView("PH_ISSUE")
DF_PD_ISSUE.createOrReplaceTempView("PD_ISSUE")
DF_pm_part.createOrReplaceTempView("pm_part")
df= spark.sql("""(Select Raw_Transaction_Type,
               Item_Code,
               '' Prefix,
               Warehouse_code,
               Warehouse_Grp_Cd,
               Sales_Order_Num,
               Sales_Ord_Line_Num,
               Extraction_date,
               sum(Ordered_Qty - return_qty - Cancel_Qty) Ordered_quantity,
               sum(Sale_Qty - return_qty) Supplied_quantity,
               Demand_Date,
               Customer_Code,
               Use_For_Forcasting,
               Use_For_Service_Level,
               Use_For_Classification,
               Stock_demand_date,
               Sales_Type,
               Job_Card_Number,
               Max(Job_Card_Status) Job_Card_Status,
               Party_Type,
               Service_Type,
               Use_For_Sales_Value_KPI,
               Demand_Stream,
               Direct_Demand,
               DATE_FORMAT(Order_date, 'dd-MM-yyyy') Order_date  , 
               CURRENT_TIMESTAMP() Created_date
          from (SELECT 
                 'M' Raw_Transaction_Type,
                 PD.PART_NUM Item_Code,
                 '' Prefix,
                 AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                 AM.LOC_CD Warehouse_code,
                 AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                 PH.SO_NUM Sales_Order_Num,
                 AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                 PH.SO_NUM || PD.PART_NUM || DATE_FORMAT(PH.So_Date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                 DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,  
                 nvl(PD.SO_QTY, 0) Ordered_Qty,
                 0 Sale_Qty,
                 0 Cancel_Qty,
                 0 Return_Qty,
                 DATE_FORMAT(PH.So_Date, 'yyyyMMdd') Demand_Date,
                 '' Customer_Code,
                 'N' Use_For_Forcasting,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   else
                    ''
                 end as Use_For_Service_Level,
                 'N' Use_For_Classification,
                 '' Stock_demand_date,
                 'Counter Sale' Sales_Type,
                 '' Job_Card_Number,
                 '' Job_Card_Status,
                 PH.Party_Type Party_Type,
                 '' Service_Type,
                 'N' Use_For_Sales_Value_KPI,
                 '' Demand_Stream,
                 '' Direct_Demand,
                 '' Order_date
                  FROM PH_SO             PH,
                       PD_SO             PD,
                       AM_DEALER_LOC     AM,
                       am_company_master ma
                 WHERE PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
                   AND PH.LOC_CD = PD.LOC_CD
                   AND PH.PARENT_GROUP = PD.PARENT_GROUP
                   AND PH.SO_NUM = PD.SO_NUM
                   AND PH.COMP_FA = PD.COMP_FA
                   AND PD.SRL_NUM > 0
                   AND PH.DEALER_MAP_CD = AM.DEALER_MAP_CD
                   AND PH.LOC_CD = AM.LOC_CD
                   AND PH.PARENT_GROUP = AM.PARENT_GROUP
                   AND PH.Comp_Fa = MA.Comp_Code
                   and PH.So_Date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and PH.So_Date < current_date().cast("string") + " 16:00:00"
                   and ma.parent_group = AM.parent_group
                   and ma.dealer_map_cd = AM.dealer_map_cd
                   and AM.principal_map_cd = 1
                UNION ALL
                SELECT 
                 'M' Raw_Transaction_Type,
                 PDO.Part_Num Item_Code,
                 '' Prefix,
                 AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                 AM.LOC_CD Warehouse_code,
                 AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                 PSO.SO_NUM Sales_Order_Num,
                 AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                 PSO.SO_NUM || PDO.PART_NUM ||
                 DATE_FORMAT(PSO.So_Date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                 DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                 0 Ordered_qty,
                 nvl(PD.Bill_Qty, 0) Sale_Qty,
                 0 Cancel_Qty,
                 nvl(pd.ret_qty, 0) Return_qty,
                 DATE_FORMAT(pso.so_date, 'yyyyMMdd') Demand_Date,                 
                 '' Customer_Code,
                 'N' Use_For_Forcasting,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   else
                    ''
                 end as Use_For_Service_Level,
                 'N' Use_For_Classification,
                 '' Stock_demand_date,
                 'Counter Sale' Sales_Type,
                 '' Job_Card_Number,
                 DATE_FORMAT(PH.doc_date, 'yyyyMMdd') Job_Card_Status,
                 PH.Party_Type Party_Type,
                 '' Service_Type,
                 'N' Use_For_Sales_Value_KPI,
                 '' Demand_Stream,
                 '' Direct_Demand,
                 '' Order_date
                  from PH_ISSUE          ph,
                       PD_ISSUE          pd,
                       am_dealer_loc     AM,
                       pm_part           pm,
                       pm_part           pm1,
                       am_company_master ma,
                       PH_SO             PSO,
                       PD_SO             PDO               
                 where Ph.DOC_TYPE IN ('RSI', 'CSI')
                   AND ph.parent_group = AM.parent_group
                   and ph.dealer_map_cd = AM.dealer_map_cd
                   and ph.loc_cd = AM.loc_cd
                   and ph.comp_fa = ma.comp_code
                   and ph.doc_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and ph.doc_date < current_date().cast("string") + " 16:00:00"
                   and PSO.So_Date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and PSO.So_Date < current_date().cast("string") + " 16:00:00"
                   and pd.parent_group = ph.parent_group
                   and pd.dealer_map_cd = ph.dealer_map_cd
                   and pd.loc_cd = ph.loc_cd
                   and pd.comp_fa = ph.comp_fa
                   and pd.doc_type = ph.doc_type
                   and pd.doc_num = ph.doc_num
                   and pd.srl_num >= 0
                   AND PM.PART_NUM = pd.PART_NUM
                   AND PM.DEALER_MAP_CD = 1
                   and ma.parent_group = AM.parent_group
                   and ma.dealer_map_cd = AM.dealer_map_cd
                   and AM.principal_map_cd = 1
                   AND PSO.DEALER_MAP_CD = PDO.DEALER_MAP_CD
                   AND PSO.LOC_CD = PDO.LOC_CD
                   AND PSO.PARENT_GROUP = PDO.PARENT_GROUP
                   AND PSO.SO_NUM = PDO.SO_NUM
                   AND PSO.COMP_FA = PDO.COMP_FA
                   and pdo.part_num = pd.part_num
                   AND PDO.SRL_NUM > 0
                   and pso.parent_group = ph.parent_group
                   and pso.dealer_map_cd = ph.dealer_map_cd
                   and pso.loc_cd = ph.loc_cd
                   and pso.comp_fa = ph.comp_fa
                   and pso.so_num = pd.ref_doc_num
                   AND PM.PART_NUM = pd.PART_NUM
                   AND PM.DEALER_MAP_CD = 1
                   AND PM1.PART_NUM = pdo.PART_NUM
                   AND PM1.DEALER_MAP_CD = 1
                
                UNION ALL
                SELECT 
                 'M' Raw_Transaction_Type,
                 PD.PART_NUM Item_Code,
                 '' Prefix,
                 AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' ||
                 AM.LOC_CD Warehouse_code,
                 AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                 PH.SO_NUM Sales_Order_Num,
                 AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                 PH.SO_NUM || PD.PART_NUM || DATE_FORMAT(PH.So_Date, 'yyMMdd') || 'R' Sales_Ord_Line_Num,
                 DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                 0 Ordered_Qty,
                 0 Sale_Qty,
                 CASE WHEN NVL(PD.Cancel_qty, 0) > NVL(pd.so_qty,0) then
                   nvl(pd.so_qty,0)
                 else
                   nvl(pd.cancel_qty,0)
                  end as  Cancel_QTY,
                 0 Return_qty,
                 DATE_FORMAT(ph.so_date, 'yyyyMMdd') Demand_Date,                 
                 '' Customer_Code,
                 'N' Use_For_Forcasting,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   else
                    ''
                 end as Use_For_Service_Level,
                 'N' Use_For_Classification,
                 '' Stock_demand_date,
                 'Counter Sale' Sales_Type,
                 '' Job_Card_Number,
                 '' Job_Card_Status,
                 PH.Party_Type Party_Type,
                 '' Service_Type,
                 'N' Use_For_Sales_Value_KPI,
                 '' Demand_Stream,
                 '' Direct_Demand,
                 '' Order_date
                  FROM PH_SO             PH,
                       PD_SO             PD,
                       AM_DEALER_LOC     AM,
                       am_company_master ma
                 WHERE PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
                   AND PH.LOC_CD = PD.LOC_CD
                   AND PH.PARENT_GROUP = PD.PARENT_GROUP
                   AND PH.SO_NUM = PD.SO_NUM
                   AND PH.COMP_FA = PD.COMP_FA
                   AND PH.DEALER_MAP_CD = AM.DEALER_MAP_CD
                   AND PH.LOC_CD = AM.LOC_CD
                   AND PH.PARENT_GROUP = AM.PARENT_GROUP
                   and ph.comp_fa = ma.comp_code
                   and ma.parent_group = AM.parent_group
                   and ma.dealer_map_cd = AM.dealer_map_cd
                   and AM.principal_map_cd = 1
                   and PD.canceled_date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and PD.canceled_date < current_date().cast("string") + " 16:00:00"
                   and PH.So_Date >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and PH.So_Date < current_date().cast("string") + " 16:00:00"
         group by Raw_Transaction_Type,
                  Item_Code,
                  Warehouse_code,
                  Warehouse_Grp_Cd,
                  Sales_Order_Num,
                  Sales_Ord_Line_Num,
                  Extraction_date,
                  Demand_Date,
                  Customer_Code,
                  Use_For_Forcasting,
                  Use_For_Service_Level,
                  Use_For_Classification,
                  Sales_Type,
                  Job_Card_Number,                  
                  Party_Type,
                  Service_Type,
                  Use_For_Sales_Value_KPI,
                  Demand_Stream,
                  Direct_Demand,
                  Order_Date,
                  Stock_demand_date,
                  Prefix
        
        UNION ALL
        Select Raw_Transaction_Type,
               Item_Code,
               Prefix,
               Warehouse_code,
               Warehouse_Grp_Cd,
               Sales_Order_Num,
               Sales_Ord_Line_Num,
               Extraction_date,
               sum(Sale_qty - return_qty) Ordered_quantity,
               sum(Sale_Qty - return_qty) Supplied_quantity,
               Demand_Date,
               Customer_Code,
               Use_For_Forcasting,
               Use_For_Service_Level,
               Use_For_Classification,
               Stock_demand_date,
               Sales_Type,
               Job_Card_Number,
               Job_Card_Status,
               Party_Type,
               Service_Type,
               Use_For_Sales_Value_KPI,
               Demand_Stream,
               Direct_Demand,
               DATE_FORMAT(Order_Date, 'dd-MM-yyyy'),
               CURRENT_TIMESTAMP() Created_date
          from (SELECT 
                 'M' Raw_Transaction_Type,
                 PD.PART_NUM Item_Code,
                 '' Prefix,
                 AM.PARENT_GROUP || '-' || AM.Dealer_Map_Cd || '-' ||
                 AM.LOC_CD Warehouse_code,
                 AM.Region_cd || '_' || AM.PARENT_GROUP Warehouse_Grp_Cd,
                 PSO.SO_NUM Sales_Order_Num,
                 AM.PARENT_GROUP || AM.Dealer_Map_Cd || AM.LOC_CD ||
                 PSO.SO_NUM || PD.PART_NUM || DATE_FORMAT(PH.doc_date, 'yyMMdd') || 'F' Sales_Ord_Line_Num,
                 DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                 0 Ordered_qty,
                 nvl(PD.Bill_Qty, 0) Sale_Qty,
                 0 Cancel_Qty,
                 nvl(pd.ret_qty, 0) Return_qty,
                 DATE_FORMAT(PH.doc_date, 'yyyyMMdd') Demand_Date,
                 '' Customer_Code,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   when PM.Catg_Cd = 'AA' and AM.Dealer_Type <> 'TV' and
                        am.dealer_category = 'DDL' then
                    'N'
                   else
                    ''
                 end as Use_For_Forcasting,
                 'N' Use_For_Service_Level,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   else
                    ''
                 end as Use_For_Classification,
                 '' Stock_demand_date,
                 'Counter Sale' Sales_Type,
                 '' Job_Card_Number,
                 DATE_FORMAT(pso.so_date, 'yyyyMMdd') Job_Card_Status,
                 PH.Party_Type Party_Type,
                 '' Service_Type,
                 case
                   when Ph.Party_Type in ('D', 'DI') then
                    'N'
                   else
                    ''
                 end as Use_For_Sales_Value_KPI,
                 '' Demand_Stream,
                 '' Direct_Demand,
                 '' Order_date
                  from PH_ISSUE          ph,
                       PD_ISSUE          pd,
                       am_dealer_loc     AM,
                       PM_PART           PM,
                       am_company_master ma,
                       PH_SO             PSO,
                       PD_SO             PDO                
                 where Ph.DOC_TYPE IN ('RSI', 'CSI')
                   AND ph.parent_group = AM.parent_group
                   and ph.dealer_map_cd = AM.dealer_map_cd
                   and ph.loc_cd = AM.loc_cd
                   and ph.comp_fa = ma.comp_code
                   and (ph.doc_date) >= DATE_SUB(CURRENT_TIMESTAMP(), 120)
                   and (ph.doc_date) < current_date().cast("string") + " 16:00:00"
                   and pd.parent_group = ph.parent_group
                   and pd.dealer_map_cd = ph.dealer_map_cd
                   and pd.loc_cd = ph.loc_cd
                   and pd.comp_fa = ph.comp_fa
                   and pd.doc_type = ph.doc_type
                   and pd.doc_num = ph.doc_num
                   and pd.srl_num >= 0
                   AND PM.PART_NUM = pd.PART_NUM
                   AND PM.DEALER_MAP_CD = 1
                   and ma.parent_group = AM.parent_group
                   and ma.dealer_map_cd = AM.dealer_map_cd
                   and AM.principal_map_cd = 1
                   AND PSO.DEALER_MAP_CD = PDO.DEALER_MAP_CD
                   AND PSO.LOC_CD = PDO.LOC_CD
                   AND PSO.PARENT_GROUP = PDO.PARENT_GROUP
                   AND PSO.SO_NUM = PDO.SO_NUM
                   AND PSO.COMP_FA = PDO.COMP_FA
                   and pdo.part_num = pd.part_num
                   AND PDO.SRL_NUM > 0
                   and pso.parent_group = ph.parent_group
                   and pso.dealer_map_cd = ph.dealer_map_cd
                   and pso.loc_cd = ph.loc_cd
                   and pso.comp_fa = ph.comp_fa
                   and pso.so_num = pd.ref_doc_num)
         group by Raw_Transaction_Type,
                  Item_Code,
                  Warehouse_code,
                  Warehouse_Grp_Cd,
                  Sales_Order_Num,
                  Sales_Ord_Line_Num,
                  Extraction_date,
                  Demand_Date,
                  Customer_Code,
                  Use_For_Forcasting,
                  Use_For_Service_Level,
                  Use_For_Classification,
                  Sales_Type,
                  Job_Card_Number,
                  Job_Card_Status,
                  Party_Type,
                  Service_Type,
                  Use_For_Sales_Value_KPI,
                  Demand_Stream,
                  Direct_Demand,
                  Order_Date,
                  Stock_demand_date,
                  Prefix)""")
df.show()
df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA/PH_TRANS_DEMAND_SUMMARY_DELTA/TRANS_DEMAND_CO/')
                  
job.commit()