import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

df_ph_trans_demand_summary = spark.read.parquet("s3://msil-aos-processed/DELTA/PH_TRANS_DEMAND_SUMMARY_DELTA/PH_TRAN_DEMAND_SUMMARY_DELTA/")
df_PO_PLANNING_TOOL = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/PO_PLANNING_TOOL_TOG_DELTA/')
---('s3://msil-aos-processed/history/purchase-order/20230414/*')

DF_PM_STOCK1= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_STOCK/")
DF_PM_STOCK2= spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_STOCK__ct/")
DF_PM_STOCK = DF_PM_STOCK1.unionAll(DF_PM_STOCK2)

df_AM_DEALER_LOC1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
df_AM_DEALER_LOC2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC__ct/")
df_AM_DEALER_LOC = df_AM_DEALER_LOC1.unionAll(df_AM_DEALER_LOC2)

DF_pm_part1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
DF_pm_part2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART__ct/")
DF_pm_part = DF_pm_part1.unionAll(DF_pm_part2)

DF_PM_PART_VAR1 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_VAR/")
DF_PM_PART_VAR2 = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_VAR__ct/")
DF_PM_PART_VAR = DF_PM_PART_VAR1.unionAll(DF_PM_PART_VAR2)

df_PO_PLANNING_TOOL.createOrReplaceTempView("PO_PLANNING_TOOL")
df_ph_trans_demand_summary.createOrReplaceTempView("ph_trans_demand_summary")
DF_pm_part.createOrReplaceTempView("pm_part")
DF_PM_STOCK.createOrReplaceTempView("PM_STOCK")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
DF_PM_PART_VAR.createOrReplaceTempView("PM_PART_VAR")

df = spark.sql("""(select distinct td.warehouse_code,
                       td.item_code part_num,
                       DATE_FORMAT(td.order_date, 'yyyyMMdd') order_date
         from ph_trans_demand_summary td
        where td.order_date>= date_format(date_add(date_trunc('day', current_timestamp), -36*30) ,'yyyyMMdd')
          and td.order_date < date_format(date_trunc('day', current_timestamp),'yyyyMMdd')
       UNION ALL
       select distinct po.warehouse_code,
                       po.item_code part_num,
                       DATE_FORMAT(po.order_date, 'yyyyMMdd') order_date
         from PO_PLANNING_TOOL po
        where po.order_date >= date_format(date_add(date_trunc('day', current_timestamp), -36*30) ,'yyyyMMdd')
          and po.order_date < date_format(date_trunc('day', current_timestamp),'yyyyMMdd')
       UNION ALL
       select distinct am.parent_group || '-' || am.dealer_map_cd || '-' ||
                       am.loc_cd warehouse_code,
                       ps.part_num part_num,
                       (CURRENT_TIMESTAMP()) order_date
         from PM_STOCK ps, am_dealer_loc am
        where 1 = 1
          and am.parent_group = ps.parent_group
          and am.loc_Cd = ps.Loc_Cd
          and am.dealer_map_cd = ps.dealer_map_cd             
          and COALESCE(am.msil_terminated_date, DATE_ADD(CURRENT_DATE(), 1)) > CURRENT_DATE()
          and am.principal_map_cd = 1
          AND COALESCE(COALESCE(os_stock_qty, 0) + COALESCE(ls_stock_qty, 0) -
                  (COALESCE(os_float_qty, 0) + COALESCE(ls_float_qty, 0) +
                   COALESCE(alloc_qty, 0) + COALESCE(ws_resrv_qty, 0)),
                  0) <> 0
       
       UNION ALL
       select distinct am.parent_group || '-' || am.dealer_map_cd || '-' ||
                       am.loc_cd warehouse_code,
                       pm.part_num part_num,
                       (pm.eff_from_date) order_date
         from pm_part pm, am_dealer_loc am, pm_part_var pv
        where 1 = 1
          and am.parent_group = pv.parent_group
          and am.loc_Cd = pv.loc_cd
          and am.dealer_map_cd = pv.dealer_map_cd
          and COALESCE(am.msil_terminated_date, DATE_ADD(CURRENT_DATE(), 1)) > CURRENT_DATE()
          and am.principal_map_cd = 1
          and pm.part_num = pv.part_num
          and pm.dealer_map_cd = 1
          and pm.principal_map_cd = 1
          and pm.eff_from_date >= DATE_SUB(CURRENT_TIMESTAMP(), 365))""")
          
          
df.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/pm-part-selection/"