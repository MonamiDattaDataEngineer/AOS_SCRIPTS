
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import to_date
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
df_ph_trans_demand_co = spark.read.parquet("s3://msil-aos-processed/DELTA/PH_TRANS_DEMAND_SUMMARY_DELTA/TRANS_DEMAND_CO/")
df_ph_trans_demand_indent= spark.read.parquet("s3://msil-aos-processed/DELTA_0908/TRANS_DEMAND/TRANS_DEMAND_INDNT/")
df_ph_trans_demand_workshop=spark.read.parquet("s3://msil-aos-processed/DELTA_0908/TRANS_DEMAND/TRANS_DEMAND_WORKSHOP/")

df_ph_trans_demand_co.createOrReplaceTempView("ph_trans_demand_co_poc")
df_ph_trans_demand_workshop.createOrReplaceTempView("PH_TRANS_DEMAND_WORKSHOP_POC")
df_ph_trans_demand_indent.createOrReplaceTempView("ph_trans_demand_indent_POC")
df1 = spark.sql("""(Select RAW_TRANSACTION_TYPE,
             ITEM_CODE,
             PREFIX,
             WAREHOUSE_CODE,
             WAREHOUSE_GRP_CD,
             SALES_ORDER_NUM,
             SALES_ORD_LINE_NUM,
             EXTRACTION_DATE,
             CEIL(Ordered_quantity) ORDERED_QUANTITY,
             CEIL(Supplied_quantity) SUPPLIED_QUANTITY,
             DEMAND_DATE,
             CUSTOMER_CODE,
             USE_FOR_FORCASTING,
             USE_FOR_SERVICE_LEVEL,
             USE_FOR_CLASSIFICATION,
             STOCK_DEMAND_DATE,
             SALES_TYPE,
             JOB_CARD_NUMBER,
             JOB_CARD_STATUS,
             PARTY_TYPE,
             SERVICE_TYPE,
             USE_FOR_SALES_VALUE_KPI,
             DEMAND_STREAM,
             DIRECT_DEMAND,
             ORDER_DATE,
             CREATED_DATE
        from (Select Raw_Transaction_Type,
                     Item_Code,
                     Prefix,
                     Warehouse_code,
                     Warehouse_Grp_Cd,
                     Sales_Order_Num,
                     Sales_Ord_Line_Num,
                     Extraction_date,
                     Ordered_quantity,
                     Supplied_quantity,
                     Demand_Date,
                     Customer_Code,
                     Use_For_Forcasting,
                     Use_For_Service_Level,
                     Use_For_Classification,
                     Stock_demand_date,
                     Sales_Type,
                     Job_Card_Number,
                     Job_Card_Status,
                     Party_Type,
                     Service_Type,
                     Use_For_Sales_Value_KPI,
                     Demand_Stream,
                     Direct_Demand,
                     DATE_FORMAT(Order_Date, 'yyyyMMdd') Order_Date,
                     co.created_date
                from ph_trans_demand_co_poc co              
              UNION ALL
              Select Raw_Transaction_Type,
                     Item_Code,
                     Prefix,
                     Warehouse_code,
                     Warehouse_Grp_Cd,
                     Sales_Order_Num,
                     Sales_Ord_Line_Num,
                     Extraction_date,
                     Ordered_quantity,
                     Supplied_quantity,
                     Demand_Date,
                     Customer_Code,
                     Use_For_Forcasting,
                     Use_For_Service_Level,
                     Use_For_Classification,
                     Stock_demand_date,
                     Sales_Type,
                     Job_Card_Number,
                     Job_Card_Status,
                     Party_Type,
                     Service_Type,
                     Use_For_Sales_Value_KPI,
                     Demand_Stream,
                     Direct_Demand,
                     DATE_FORMAT(Order_Date, 'yyyyMMdd') Order_Date,
                     wp.created_date
                from PH_TRANS_DEMAND_WORKSHOP_POC wp            
              UNION all
              Select Raw_Transaction_Type,
                     Item_Code,
                     Prefix,
                     Warehouse_code,
                     Warehouse_Grp_Cd,
                     Sales_Order_Num,
                     Sales_Ord_Line_Num,
                     Extraction_date,
                     Ordered_quantity,
                     Supplied_quantity,
                     Demand_Date,
                     Customer_Code,
                     Use_For_Forcasting,
                     Use_For_Service_Level,
                     Use_For_Classification,
                     Stock_demand_date,
                     Sales_Type,
                     Job_Card_Number,
                     Job_Card_Status,
                     Party_Type,
                     Service_Type,
                     Use_For_Sales_Value_KPI,
                     Demand_Stream,
                     Direct_Demand,
                     DATE_FORMAT(Order_Date, 'yyyyMMdd') Order_Date,
                     pi.created_date
                from ph_trans_demand_indent_POC pi))""")

df1.show()
df1.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA_0908/TRANS_DEMAND/TRANS_DEMAND_SUMMARY/')

job.commit()