# IMPORTS

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException

# SPARK CONFIG

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
sc.setLogLevel('DEBUG')
logger = glueContext.get_logger()
logger.info('##############TASK-0-IMPORTS+SPARK_CONFIG-COMPLETED################')
print('##############TASK-0-IMPORTS+SPARK_CONFIG-COMPLETED################')

#######################################TASK-1#################################################
# PARAMETERS
parser = argparse.ArgumentParser()
parser.add_argument('--JOB_NAME')
parser.add_argument('--DATA_SOURCE_PATH')
parser.add_argument('--DATA_TARGET_PATH')
parser.add_argument('--PM_PART_SELECTION_PATH')

args, unknown = parser.parse_known_args()

JOB_NAME = args.JOB_NAME
DATA_SOURCE_PATH = args.DATA_SOURCE_PATH
DATA_TARGET_PATH = args.DATA_TARGET_PATH
PM_PART_SELECTION_PATH = args.PM_PART_SELECTION_PATH


# SET PATH
target_write_path = DATA_TARGET_PATH # + JOB_NAME.split('jb_')[1]

logger.info('##############TASK-1-PARAMETERS+SET_PATH-COMPLETED################')
print('##############TASK-1-PARAMETERS+SET_PATH-COMPLETED################')

#######################################TASK-2#################################################

df_pm_part_selection = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PM_PART_SELECTION-0103/').select(['WAREHOUSE_CODE', 'PART_NUM'])
df_pm_part_selection.createOrReplaceTempView('PM_PART_SELECTION')

df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/').select(['LOC_CD', 'DEALER_MAP_CD', 'PARENT_GROUP', 'MUL_DEALER_CD', 'PRINCIPAL_MAP_CD', 'CONSG_CD', 'SPARES_STOCK_YARD_YN', 'REGION_CD', 'OUTLET_CD'])
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')

df_am_consignee = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_CONSIGNEE/').select(['CONSG_CD', 'RPDC_STATUS', 'PRINCIPAL_MAP_CD'])
df_am_consignee.createOrReplaceTempView('AM_CONSIGNEE')

df_am_list = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_LIST/').select(['PRINCIPAL_MAP_CD', 'LIST_NAME', 'LIST_DESC', 'LIST_CODE'])
df_am_list.createOrReplaceTempView('AM_LIST')

df_pm_part_source = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_SOURCE/').select(['PART_NUM', 'PRINCIPAL_MAP_CD', 'PART_COMP_CD', 'SERVE_FLAG'])
df_pm_part_source.createOrReplaceTempView('PM_PART_SOURCE')

df_pm_part = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/').select(['ROOT_PART_NUM', 'DEALER_MAP_CD', 'CATG_CD', 'PART_DESC', 'UOM_CD', 'PART_NUM', 'EFF_FROM_DATE', 'TAG_CD', 'CLOSED_DATE'])
df_pm_part.createOrReplaceTempView('PM_PART')

logger.info('##############DATA-LOADED################')
print('##############DATA-LOADED################')

df_pps_am = spark.sql('''
with
pps as (
select
    distinct
        PART_NUM
from
    pm_part_selection
),
am as (
select
    distinct
        dealer_map_cd,
        parent_group,
        loc_cd
from
    AM_DEALER_LOC
)
        
select
    am.dealer_map_cd d_map_cd,
    am.parent_group p_group,
    am.loc_cd l_cd,
    PPS.part_num partno
FROM 
    PPS, AM
''')
df_pps_am.createOrReplaceTempView('pps_am')

query_pps_am = '''
with
t1 as (
select
    pps_am.d_map_cd,
    pps_am.p_group,
    pps_am.l_cd,
    pps_am.partno,
    (select
        first(nvl(cn.rpdc_status, '01')) lv_cons_rpdc
    from
        am_dealer_loc am
    join
        am_consignee cn
        on  am.consg_cd = cn.consg_cd
        and am.principal_map_cd = cn.principal_map_cd
    where 
        dealer_map_cd = pps_am.d_map_cd
        and loc_cd = pps_am.l_cd
        and parent_group = pps_am.p_group) lv_cons_rpdc,
    (select
        first(am.principal_map_cd) 
    from 
        am_dealer_loc am 
    join
        am_consignee cn
        on  am.consg_cd = cn.consg_cd
        and am.principal_map_cd = cn.principal_map_cd
    where 
        dealer_map_cd = pps_am.d_map_cd
        and loc_cd = pps_am.l_cd
        and parent_group = pps_am.p_group) ln_pmc
from
    pps_am
),
t2 as (
select
    ps.part_num,
    al.principal_map_cd,
    al.list_code,
    al.list_desc
from 
    pm_part_source ps
    join am_list al
    on  ps.serve_flag = 'Y'
    and al.list_name = 'RPDC_SOURCE'
    and al.list_code = ps.part_comp_cd
    and al.principal_map_cd = ps.principal_map_cd
),
t3 as (
select
    *
from
    t1
    left join
        t2
        on  t2.part_num = t1.partno
        and t2.principal_map_cd = t1.ln_pmc
        and t2.list_code = t1.lv_cons_rpdc
) 

select
    distinct
        *,
        coalesce(case
            when
                lv_cons_rpdc='01'
            then 'GGN'
            else
                list_desc
            end , 'GGN') lv_source
from 
    t3
'''

df_pm_am = spark.sql('''
with
pm as (
select
    distinct
        PART_NUM
from
    pm_part_selection
),
am as (
select
    distinct
        dealer_map_cd,
        parent_group,
        loc_cd
from
    AM_DEALER_LOC
)
        
select
    am.dealer_map_cd d_map_cd,
    am.parent_group p_group,
    am.loc_cd l_cd,
    pm.part_num partno
FROM 
    pm, AM
''')
df_pm_am.createOrReplaceTempView('pm_am')

query_pm_am = '''
with
t1 as (
select
    pm_am.d_map_cd,
    pm_am.p_group,
    pm_am.l_cd,
    pm_am.partno,
    (select
        first(nvl(cn.rpdc_status, '01')) lv_cons_rpdc
    from
        am_dealer_loc am
    join
        am_consignee cn
        on  am.consg_cd = cn.consg_cd
        and am.principal_map_cd = cn.principal_map_cd
    where 
        dealer_map_cd = pm_am.d_map_cd
        and loc_cd = pm_am.l_cd
        and parent_group = pm_am.p_group) lv_cons_rpdc,
    (select
        first(am.principal_map_cd) 
    from 
        am_dealer_loc am 
    join
        am_consignee cn
        on  am.consg_cd = cn.consg_cd
        and am.principal_map_cd = cn.principal_map_cd
    where 
        dealer_map_cd = pm_am.d_map_cd
        and loc_cd = pm_am.l_cd
        and parent_group = pm_am.p_group) ln_pmc
from
    pm_am
),
t2 as (
select
    ps.part_num,
    al.principal_map_cd,
    al.list_code,
    al.list_desc
from 
    pm_part_source ps
    join am_list al
    on  ps.serve_flag = 'Y'
    and al.list_name = 'RPDC_SOURCE'
    and al.list_code = ps.part_comp_cd
    and al.principal_map_cd = ps.principal_map_cd
),
t3 as (
select
    *
from
    t1
    left join 
        t2
        on t2.part_num = t1.partno
        and t2.principal_map_cd = t1.ln_pmc
        and t2.list_code = t1.lv_cons_rpdc
) 

select
    distinct 
        *,
        coalesce(case
            when
                lv_cons_rpdc='01'
            then 'GGN'
            else
                list_desc
            end , 'GGN') lv_source
from 
    t3
'''

df_pm_am = spark.sql(query_pm_am).withColumn('jb', F.lit('jb_sp_item_data'))
df_pps_am = spark.sql(query_pps_am).withColumn('jb', F.lit('jb_sp_replace_planning_tool'))

df = df_pm_am.unionAll(df_pps_am)
logger.info('##############TASK-2-EXECUTION_STARTED################')
print('##############TASK-2-EXECUTION_STARTED################')

#######################################TASK-3#################################################

df.write.mode('overwrite').partitionBy('jb').format('parquet').save('s3://msil-aos-processed/DELTA_0908/GET_PART_SOURCE-0103/') ##s3://msil-aos-raw/lookup/get_parts_source/

job.commit()