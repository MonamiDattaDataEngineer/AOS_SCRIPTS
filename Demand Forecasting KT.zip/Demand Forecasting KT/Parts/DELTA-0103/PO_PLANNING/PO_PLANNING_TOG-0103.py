import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

jdbc_url = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'
password = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password}


df_sp_chd_po_3yrs_co = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CHD_PO_3YRS_CO/')
df_sp_chd_po_3yrs_indt = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CHD_PO_3YRS_INDNT/')
df_sp_chd_po_3yrs_not_indt = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CHD_PO_3YRS_NOT_INDNT/')
df_sp_mother_cl03_data_3yrs = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/MOTHER_CL03_3YRS_DELTA/')

df_sp_mother_dms_data_3yrs = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/MOTHER_3YRS_DMS_DELTA/')


df = df_sp_chd_po_3yrs_co.unionAll(df_sp_chd_po_3yrs_indt).unionAll(df_sp_chd_po_3yrs_not_indt).unionAll(df_sp_mother_cl03_data_3yrs).unionAll(df_sp_mother_dms_data_3yrs)
df.show()

df.write.mode('overwrite').format('parquet').save('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/PO_PLANNING_TOG_DELTA-0103/')
##df.write.format('jdbc').mode('append').options(url=jdbc_url, password=password, user=username, dbtable=dbtable, batchsize=500000).save()
job.commit()