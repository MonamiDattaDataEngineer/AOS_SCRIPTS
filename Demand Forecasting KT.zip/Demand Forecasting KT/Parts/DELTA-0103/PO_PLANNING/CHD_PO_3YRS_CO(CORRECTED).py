##has the proper modification
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

df_ph_so = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_SO/')
#df_ph_so.cache()
df_ph_so.createOrReplaceTempView('PH_SO')
#df_ph_so.count()
df_pd_so = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_SO/')
#df_pd_so.cache()
df_pd_so.createOrReplaceTempView('PD_SO')
#df_pd_so.count()
df_pd_issue = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_ISSUE/')
#df_pd_issue.cache()
df_pd_issue.createOrReplaceTempView('PD_ISSUE')
#df_pd_issue.count()
df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/')
#df_am_dealer_loc.cache()
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
#df_am_dealer_loc.count()
df_am_company_master = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/')
#df_am_company_master.cache()
df_am_company_master.createOrReplaceTempView('AM_COMPANY_MASTER')
#df_am_company_master.count()
df_pm_part = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/')
#df_pm_part.cache()
df_pm_part.createOrReplaceTempView('PM_PART')
#df_pm_part.count()
df_ph_issue = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/')
#df_ph_issue.cache()
df_ph_issue.createOrReplaceTempView('PH_ISSUE')
#df_ph_issue.count()
df_ph_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_RECEIPTS/')
#df_ph_receipts.cache()
df_ph_receipts.createOrReplaceTempView('PH_RECEIPTS')
#df_ph_receipts.count()
df_pd_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_RECEIPTS/')
#df_pd_receipts.cache()
df_pd_receipts.createOrReplaceTempView('PD_RECEIPTS')
#df_pd_receipts.count()

query = '''
SELECT
    'M' ROW_TRANS_TYPE,
    T1.ORDERED_PART_NUM ITEM_CODE,
    T1.WAREHOUSE_CODE WAREHOUSE_CODE,
    T1.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
    T1.INDENT_NUM ORDER_NUM,
    T1.WAREHOUSE_CODE || '-' || T1.ORDERED_PART_NUM || '-' || T1.INDENT_NUM ORDER_LINE_NUM,
    --TO_CHAR(SYSDATE, 'YYYYMMDD') || 'T' || TO_CHAR(SYSDATE, 'HH24MI') EXTRACTION_DATE,
    CONCAT(date_format(current_timestamp(),'yyyyMMdd'),'T',date_format(current_timestamp(),'HHmm')) EXTRACTION_DATE,
    --SYSDATE CREATED_DATE,
    current_timestamp() CREATED_DATE,
    T1.INDENT_TO SUPP_CODE,
    ceil(T1.INDENT_QTY) ORDER_QTY,
    --TO_CHAR(T1.INDENT_DATE, 'YYYYMMDD') ORDER_DATE,
    T1.INDENT_DATE ORDER_DATE,
    --ceil(DECODE(T1.Mrn_Date, NULL, NULL, T1.Mrn_QTY)) RECVD_QTY,
    CEIL(CASE WHEN T1.Mrn_Date IS NULL THEN NULL ELSE T1.Mrn_QTY END) RECVD_QTY,
    --TO_CHAR(T1.Mrn_Date, 'YYYYMMDD') RECVD_DATE
    date_format(to_date(T1.Mrn_Date), 'yyyyMMdd') as RECVD_DATE
    
FROM
    (SELECT
        PD.PART_NUM ORDERED_PART_NUM,
        AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD WAREHOUSE_CODE,
        AM1.REGION_CD || '_' || AM1.PARENT_GROUP WAREHOUSE_GROUP_CODE,
        pd.so_num INDENT_NUM,
        PH.DEALER_MAP_CD || PH.LOC_CD INDENT_TO,
        PD.SO_QTY INDENT_QTY,
        date_format(to_date(PH.SO_DATE), 'yyyyMMdd') INDENT_DATE,
        PDS.BILL_QTY Mrn_QTY,
        (select 
            to_date(NVL(first(pd2.Modified_Date), first(PD2.CREATED_DATE)))
        from 
            ph_receipts pr1,
            PD_RECEIPTS pD2
        where 
            pr1.invoice_num = PDS.DOC_NUM
            And PR1.parent_group = AM1.PARENT_GROUP
            AND PR1.DEALER_MAP_CD = AM1.DEALER_MAP_CD
            AND PR1.LOC_CD = AM1.Loc_cd
            AND PR1.COMP_FA = ac.comp_code
            AND PR1.Rec_Doc_Date is not null
            AND PD2.DEALER_MAP_CD = PR1.DEALER_MAP_CD
            AND PD2.REC_DOC_TYPE = PR1.REC_DOC_TYPE
            AND PD2.REC_DOC_NUM = PR1.REC_DOC_NUM
             AND PD2.COMP_FA = PR1.COMP_FA
            AND PD2.LOC_CD = PR1.LOC_CD
            AND PD2.REC_DOC_SRL > 0
            AND PD2.PARENT_GROUP = PR1.PARENT_GROUP
            AND PD2.PART_NUM = PDS.PART_NUM
            AND PD2.RECEIVE_STOCK = 'Y'
            AND PD2.BATCH_NUM = PDS.BATCH) Mrn_Date
    FROM
        Ph_So PH,
        AM_DEALER_LOC AM1,
        am_company_master ma,
        pm_part pm,
        pm_part pm1,
        PD_ISSUE pds
    JOIN
        Pd_So PD
        on  PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
        AND PH.LOC_CD = PD.LOC_CD
           AND PH.PARENT_GROUP = PD.PARENT_GROUP
        AND PH.SO_NUM = PD.SO_NUM
        AND PH.COMP_FA = PD.COMP_FA
        AND PD.SRL_NUM > 0
        and pd.canceled_date is null
    JOIN
        PH_ISSUE phs
        ON  pds.parent_group = phs.parent_group
        and pds.dealer_map_cd = phs.dealer_map_cd
        and pds.loc_cd = phs.loc_cd
        and pds.comp_fa = phs.comp_fa
        and pds.doc_type = phs.doc_type
        and pds.doc_num = phs.doc_num
     
          
       
  

    left join
        am_company_master ac
        on ac.dealer_map_cd = am1.dealer_map_cd
    WHERE
        PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
        AND PH.LOC_CD = PD.LOC_CD
        AND PH.PARENT_GROUP = PD.PARENT_GROUP
        AND PH.SO_NUM = PD.SO_NUM
        AND PH.COMP_FA = PD.COMP_FA
        AND PD.SRL_NUM > 0
        AND PH.Comp_Fa = MA.Comp_Code
        and to_date(PH.So_Date) >= to_date('2022-03-01')
        and to_date(PH.So_Date) < to_date('2023-07-15')
        and ma.parent_group = PH.parent_group
        and ma.dealer_map_cd = PH.dealer_map_cd
        and ph.party_type in ('D', 'DI')
        and pd.canceled_date is null
        AND PM.PART_NUM = pd.PART_NUM
        AND PM.DEALER_MAP_CD = 1
        and pds.parent_group = phs.parent_group
        and pds.dealer_map_cd = phs.dealer_map_cd
        and pds.loc_cd = phs.loc_cd
        and pds.comp_fa = phs.comp_fa
         and pds.doc_type = phs.doc_type
        and pds.doc_num = phs.doc_num
        and pds.srl_num >= 0
        and pds.ref_doc_num = pd.so_num
        AND PH.PARENT_GROUP = PHS.PARENT_GROUP
        AND PH.DEALER_MAP_CD = PHS.DEALER_MAP_CD
        AND PH.LOC_CD = PHS.LOC_CD
        AND PH.COMP_FA = PHS.COMP_FA
        AND PM1.PART_NUM = pds.PART_NUM
        AND PM1.DEALER_MAP_CD = 1
        and PM.ROOT_PART_NUM = PM1.ROOT_PART_NUM
        AND PH.PARTY_CD = AM1.DEALER_MAP_CD || AM1.LOC_CD
        AND AM1.Principal_Map_Cd = 1
        
        
        
        ) T1
'''
##KEEP AS IT IS
##AND PH.PARTY_CD = AM1.DEALER_MAP_CD || AM1.LOC_CD
##                 AND AM1.Principal_Map_Cd = 1
df = spark.sql(query)
df.show()
#df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/PRATH_DELTA/PO_PLANNING_TOOL/CHD_3YRS_CO_PRATH/')