import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


from pyspark.sql.functions import col
df_open_po_cl = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.OPEN_PO_CL/').select(['INVO_DATE', 'ORDP_ITEM_CODE', 'ORDE_DATE', 'INVD_ITEM_CODE', 'ORDE_REF_NO', 'BATCH_NUM', 'STATUS', 'CREATED_DATE', 'ORDP_QTY', 'PACP_QTY', 'ORDE_CONS_ID', 'ORDE_NO', 'INVO_NO'])
##df_open_po_cl.filter(col("INVO_DATE")>"2023-02-28").show()

##check
##from pyspark.sql.functions import col
##df=spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.OPEN_PO_CL/')
##df.count()
##df.filter(col("INVO_DATE")>"2023-02-28").count()




df_open_po_cl.createOrReplaceTempView('OPEN_PO_CL')
df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/').select(['PARENT_GROUP', 'DEALER_CATEGORY', 'CONSG_CD', 'PRINCIPAL_MAP_CD', 'LOC_CD', 'REGION_CD', 'DEALER_MAP_CD', 'SPARES_STOCK_YARD_YN'])
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
df_ph_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_RECEIPTS/').select(['LOC_CD', 'INVOICE_NUM', 'COMP_FA', 'SUPPLIER_CD', 'REC_DOC_TYPE', 'PARENT_GROUP', 'REC_DOC_NUM', 'DEALER_MAP_CD'])
df_ph_receipts.createOrReplaceTempView('PH_RECEIPTS')
df_pd_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_RECEIPTS/').select(['COMP_FA', 'PART_NUM', 'REC_DOC_TYPE', 'CREATED_DATE', 'LOC_CD', 'MODIFIED_DATE', 'DEALER_MAP_CD', 'RECEIVE_STOCK', 'REC_DOC_NUM', 'REC_DOC_SRL', 'BATCH_NUM', 'PARENT_GROUP'])
df_pd_receipts.createOrReplaceTempView('PD_RECEIPTS')

dft1 = spark.sql('''
with
    get_MODIFIED_DATE_CREATED_DATE as (
    SELECT
        PD.MODIFIED_DATE,
        PD.CREATED_DATE,
        PH.DEALER_MAP_CD,
        PD.LOC_CD,
        regexp_extract(PH.INVOICE_NUM, '([^-]+)-([^-]+)', 2) AS INVO_NO,
        PD.PART_NUM,
        PD.BATCH_NUM
    from
        ph_receipts ph
    JOIN
        PD_RECEIPTS PD
        ON PH.SUPPLIER_CD = 'MUL'
        AND PD.DEALER_MAP_CD = PH.DEALER_MAP_CD
        AND PD.REC_DOC_TYPE = PH.REC_DOC_TYPE
        AND PD.REC_DOC_NUM = PH.REC_DOC_NUM
        AND PD.COMP_FA = PH.COMP_FA
        AND PD.LOC_CD = PH.LOC_CD
        AND PD.REC_DOC_SRL > 0
        AND PD.PARENT_GROUP = PH.PARENT_GROUP
        AND PD.RECEIVE_STOCK = 'Y'
)

SELECT
    'M' ROW_TRANS_TYPE,
    T1.ORDP_ITEM_CODE ITEM_CODE,
    T1.WAREHOUSE_CODE WAREHOUSE_CODE,
    T1.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
    T1.INDENT_NUM ORDER_NUM,
    concat(T1.ORDE_CONS_ID, '-', T1.ORDP_ITEM_CODE, '-', substring(T1.INDENT_NUM, 1, 28)) ORDER_LINE_NUM,
    concat(date_format(current_timestamp(), 'yyyyMMdd'), 'T', date_format(current_timestamp(), 'HHmm')) EXTRACTION_DATE,
    current_timestamp() as CREATED_DATE,
    'MSIL' SUPP_CODE,
    T1.INDENT_QTY,
    T1.INDENT_NUM,
    T1.ORDE_CONS_ID,
    T1.ORDP_ITEM_CODE,
    date_format(to_date(T1.INDENT_DATE), 'yyyyMMdd') as ORDER_DATE,
    CASE WHEN T1.MRN_DATE IS NULL THEN NULL ELSE CEIL(T1.MRN_QTY) END AS RECVD_QTY,
    date_format(to_date(T1.MRN_DATE), 'yyyyMMdd') as RECVD_DATE
FROM
    (
    SELECT 
        PML.ORDP_ITEM_CODE ORDP_ITEM_CODE,
        AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
        AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
        PML.ORDE_REF_NO INDENT_NUM,
        PML.ORDP_QTY INDENT_QTY,
        PML.ORDE_CONS_ID,
        to_date(PML.ORDE_DATE) INDENT_DATE,
        SUM(PML.PACP_QTY) MRN_QTY,
        MAX(NVL(get_MODIFIED_DATE_CREATED_DATE.MODIFIED_DATE, get_MODIFIED_DATE_CREATED_DATE.CREATED_DATE)) MRN_DATE
    FROM OPEN_PO_CL PML,
        AM_DEALER_LOC AM
    left JOIN
        get_MODIFIED_DATE_CREATED_DATE
        on  get_MODIFIED_DATE_CREATED_DATE.DEALER_MAP_CD = AM.DEALER_MAP_CD
        and get_MODIFIED_DATE_CREATED_DATE.LOC_CD = AM.LOC_CD
        AND get_MODIFIED_DATE_CREATED_DATE.INVO_NO = PML.INVO_NO
        AND get_MODIFIED_DATE_CREATED_DATE.PART_NUM = PML.INVD_ITEM_CODE
        AND get_MODIFIED_DATE_CREATED_DATE.BATCH_NUM = PML.BATCH_NUM
    WHERE 
        PML.STATUS IN ('INVOCE_DET')
        AND AM.PRINCIPAL_MAP_CD = 1
        AND AM.CONSG_CD = PML.ORDE_CONS_ID
        AND AM.SPARES_STOCK_YARD_YN = 'Y'
        AND to_date(PML.INVO_DATE) < to_date('2023-07-15')
        AND to_date(PML.INVO_DATE) >= to_date('2023-03-01')
        
    GROUP BY
        PML.ORDP_ITEM_CODE,
        AM.PARENT_GROUP,
        AM.DEALER_MAP_CD,
        AM.LOC_CD,
        AM.REGION_CD,
        PML.ORDE_REF_NO,
        PML.ORDP_QTY,
        PML.ORDE_CONS_ID,
        to_date(PML.ORDE_DATE)) t1
''')

dft1.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CL03_STAGE_PATH/')
dft1 = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CL03_STAGE_PATH/')
dft1.createOrReplaceTempView('t1')

df1 = spark.sql('''
select
    ROW_TRANS_TYPE,
    ITEM_CODE,
    WAREHOUSE_CODE,
    WAREHOUSE_GROUP_CODE,
    ORDER_NUM,
    ORDER_LINE_NUM,
    EXTRACTION_DATE,
    CREATED_DATE,
    SUPP_CODE,
    ceil(GREATEST((T1.INDENT_QTY -
                             NVL((SELECT SUM(PML1.ORDP_QTY)
                                    FROM OPEN_PO_CL PML1
                                   WHERE PML1.ORDE_REF_NO = T1.INDENT_NUM
                                     AND PML1.ORDE_CONS_ID =
                                         T1.ORDE_CONS_ID
                                     AND PML1.ORDP_ITEM_CODE =
                                         T1.ORDP_ITEM_CODE
                                     AND PML1.STATUS = 'CANCEL_DET'),                                     
                                  0)),
                             0)) ORDER_QTY,
    
    ORDER_DATE,
    RECVD_QTY,
    RECVD_DATE
from
    t1
''')

df2 = spark.sql('''
SELECT
    CASE 
        WHEN PML.STATUS = 'FRESH_ORDER_DET' 
        THEN 'M'
        ELSE 'D' 
    END  ROW_TRANS_TYPE,
    PML.ORDP_ITEM_CODE ITEM_CODE,
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
    AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    PML.ORDE_NO ORDER_NUM,
    PML.ORDE_CONS_ID || '-' || PML.ORDP_ITEM_CODE || '-' || SUBSTR(PML.ORDE_NO, 1, 28) ORDER_LINE_NUM,
    concat(date_format(current_timestamp(), 'yyyyMMdd'), 'T', date_format(current_timestamp(), 'HHmm')) EXTRACTION_DATE,
    current_timestamp() as CREATED_DATE,
    'MSIL' SUPP_CODE,
    (CASE
        WHEN PML.STATUS = 'FRESH_ORDER_DET' 
        THEN ceil(GREATEST((PML.ORDP_QTY - NVL(
                                                (SELECT SUM(PML1.ORDP_QTY)
                                                FROM OPEN_PO_CL PML1
                                                WHERE PML1.ORDE_REF_NO = PML.ORDE_REF_NO
                                                    AND PML1.ORDE_CONS_ID = PML.ORDE_CONS_ID
                                                    AND PML1.ORDP_ITEM_CODE = PML.ORDP_ITEM_CODE
                                                    AND PML1.STATUS = 'CANCEL_DET'), 0)), 0))
        ELSE ceil(PML.ORDP_QTY)
    END)
    ORDER_QTY,
    date_format(to_date(PML.ORDE_DATE), 'yyyyMMdd') ORDER_DATE,
    NULL RECVD_QTY,
    NULL RECVD_DATE
FROM 
    OPEN_PO_CL PML,
    AM_DEALER_LOC AM
WHERE 
    PML.STATUS IN ('FRESH_ORDER_DET',
                     'EXPIRY_DET',
                     'ERROR_BATCH')
    AND PML.INVO_NO IS NULL
    AND AM.PRINCIPAL_MAP_CD = 1
    AND AM.CONSG_CD = PML.ORDE_CONS_ID
    AND AM.SPARES_STOCK_YARD_YN = 'Y'
    AND to_date(PML.ORDE_DATE) < to_date('2023-08-15') --TRUNC(SYSDATE)
    AND to_date(PML.ORDE_DATE) >= to_date('2023-03-01') --TRUNC(ADD_MONTHS(SYSDATE, -3))
    AND NOT EXISTS
        (SELECT 1
         FROM OPEN_PO_CL op
         where op.status in ('INVOCE_DET')
             AND OP.ORDE_REF_NO = PML.ORDE_REF_NO
             AND OP.ORDP_ITEM_CODE = PML.ORDP_ITEM_CODE
             AND OP.ORDE_CONS_ID = PML.ORDE_CONS_ID)
''')

df = df1.unionAll(df2)
df.show()
##df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/SP_MOTHER_CL03_DATA_3YRS_DELTA/')
##df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA/PO_PLANNING_TOOL_DELTA/SP_MOTHER_CL03_DATA_3YRS_DELTA/')