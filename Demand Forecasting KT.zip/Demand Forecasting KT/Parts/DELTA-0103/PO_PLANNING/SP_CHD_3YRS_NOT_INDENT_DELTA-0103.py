import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


df_ph_issue = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/').select(['DOC_NUM', 'DOC_DATE', 'COMP_FA', 'LOC_CD', 'REF_DOC_NUM', 'DEALER_MAP_CD', 'PARENT_GROUP'])
df_ph_issue.createOrReplaceTempView('PH_ISSUE')
df_ph_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_RECEIPTS/').select(['REC_DOC_DATE', 'FROM_LOC_CD', 'PARENT_GROUP', 'REC_DOC_TYPE', 'INVOICE_NUM', 'REC_DOC_NUM', 'LOC_CD', 'COMP_FA', 'DEALER_MAP_CD'])
df_ph_receipts.createOrReplaceTempView('PH_RECEIPTS')
df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/').select(['CONSG_CD', 'PRINCIPAL_MAP_CD', 'DEALER_MAP_CD', 'PARENT_GROUP', 'LOC_CD', 'REGION_CD'])
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
df_pd_receipts = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_RECEIPTS/').select(['COMP_FA', 'LOC_CD', 'REC_DOC_TYPE', 'REC_DOC_SRL', 'RECD_QTY', 'REC_DOC_NUM', 'PART_NUM', 'PARENT_GROUP', 'DEALER_MAP_CD'])
df_pd_receipts.createOrReplaceTempView('PD_RECEIPTS')
df_am_company_master = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/').select(['COMP_CODE', 'PARENT_GROUP', 'DEALER_MAP_CD'])
df_am_company_master.createOrReplaceTempView('AM_COMPANY_MASTER')
df_pm_part = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/').select(['DEALER_MAP_CD', 'PART_NUM', 'ROOT_PART_NUM'])
df_pm_part.createOrReplaceTempView('PM_PART')
df_ph_pick_list = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_PICK_LIST/').select(['COMP_FA', 'PARENT_GROUP', 'DEALER_MAP_CD', 'LOC_CD', 'PICK_NUM', 'REF_DOC_NUM'])
df_ph_pick_list.createOrReplaceTempView('PH_PICK_LIST')


from pyspark.sql.functions import date_sub

query = '''
with 
get_ph_issue_ref_doc_num as (
select
    PH.INVOICE_NUM,
    PH.PARENT_GROUP,
    PH.DEALER_MAP_CD,
    PH.FROM_LOC_CD,
    PH.COMP_FA,
    (select
        first(ph1.ref_doc_num)
    from
        PH_ISSUE ph1
    where
        ph1.doc_num = PH.INVOICE_NUM
        and PH1.parent_group = PH.PARENT_GROUP
        AND PH1.DEALER_MAP_CD = PH.DEALER_MAP_CD
        AND PH1.LOC_CD = PH.FROM_LOC_CD
        AND PH1.COMP_FA = PH.COMP_FA
        
        and ph1.doc_date >= to_date('2023-07-15')) ref_doc_num
    from
        ph_receipts ph
),

get_ph_pick_list_ref_doc_num as (
select
    PPL.REF_DOC_NUM,
    PPL.parent_group,
    PPL.DEALER_MAP_CD,
    PPL.LOC_CD,
    PPL.COMP_FA
from
    ph_pick_list ppl
join
    get_ph_issue_ref_doc_num
    on  PPL.PICK_NUM = nvl(get_ph_issue_ref_doc_num.ref_doc_num, 'NA')
        and PPL.parent_group = get_ph_issue_ref_doc_num.PARENT_GROUP
        AND PPL.DEALER_MAP_CD = get_ph_issue_ref_doc_num.DEALER_MAP_CD
        AND PPL.LOC_CD = get_ph_issue_ref_doc_num.FROM_LOC_CD
        AND PPL.COMP_FA = get_ph_issue_ref_doc_num.COMP_FA
)


SELECT 
    'M' ROW_TRANS_TYPE,
    T3.PART_NUM ITEM_CODE,
    T3.WAREHOUSE_CODE WAREHOUSE_CODE,
    T3.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
    CASE WHEN T3.indent_num = 'NA' THEN T3.REC_DOC_NUM ELSE NULL END ORDER_NUM, -- "INDENT_NUM", ---INDENT NA-->MRN NUM
    CONCAT(T3.WAREHOUSE_CODE,'-',T3.PART_NUM,'-',CASE WHEN T3.indent_num = 'NA' THEN T3.REC_DOC_NUM ELSE NULL END) ORDER_LINE_NUM, --- ORDER_LINE_NUM
    CONCAT(date_format(current_timestamp(),'yyyyMMdd'),'T',date_format(current_timestamp(),'HHmm')) EXTRACTION_DATE, --- EXTRACTION_DATE,
    current_timestamp() CREATED_DATE, -- CREATED_DATE,
    T3.from_loc_cd SUPP_CODE,
    ceil(T3.RECD_QTY) ORDER_QTY, -- indent_qty, ----order qty= recieve qty
    date_format(to_date(T3.MRN_DATE), 'yyyyMMdd') as ORDER_DATE, --INDENT_DATE,
    --- T3.REC_DOC_NUM "MRN_NUM",
    ceil(T3.RECD_QTY) RECVD_QTY,
    date_format(to_date(T3.MRN_DATE), 'yyyyMMdd') RECVD_DATE --- TO_CHAR(T3.MRN_DATE, 'DD-MON-YYYY') "MRN_DATE"

FROM
    (select 
        AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
        AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
        PM.ROOT_PART_NUM,
        pd.part_num,
        PD.RECD_QTY,
        PD.REC_DOC_SRL,
        PH.REC_DOC_TYPE,
        PH.PARENT_GROUP,
        PH.COMP_FA,
        PH.DEALER_MAP_CD,
        ph.from_loc_cd,
        ph.loc_cd,
        PH.REC_DOC_NUM,
        to_date(PH.REC_DOC_DATE) MRN_DATE,
        PH.INVOICE_NUM,
        NVL(
                (select 
                    first(cppl.REF_DOC_NUM)
                from 
                    get_ph_pick_list_ref_doc_num cppl
                where
                    cppl.parent_group = PH.PARENT_GROUP
                    AND cppl.DEALER_MAP_CD = PH.DEALER_MAP_CD
                    AND cppl.LOC_CD = PH.FROM_LOC_CD
                    AND cppl.COMP_FA = PH.COMP_FA), 'NA') indent_num
    from 
        ph_receipts ph,
        Pd_Receipts PD,
        AM_DEALER_LOC AM,
        am_company_master ma,
        pm_part PM
    where 
        PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
        AND PH.REC_DOC_TYPE = PD.REC_DOC_TYPE
        AND PH.REC_DOC_NUM = PD.REC_DOC_NUM
        AND PH.COMP_FA = PD.COMP_FA
        AND PH.LOC_CD = PD.LOC_CD
        AND PH.PARENT_GROUP = PD.PARENT_GROUP
        AND PD.REC_DOC_SRL > 0
        AND PH.DEALER_MAP_CD = AM.DEALER_MAP_CD
        AND PH.LOC_CD = AM.LOC_CD
        AND PH.PARENT_GROUP = AM.PARENT_GROUP
        AND PH.Comp_Fa = MA.Comp_Code
        and ma.parent_group = AM.parent_group
        and ma.dealer_map_cd = AM.dealer_map_cd
        and AM.principal_map_cd = 1
        AND PH.REC_DOC_TYPE IN ('SFR')
        AND PM.PART_NUM = PD.PART_NUM
        AND PM.DEALER_MAP_CD = 1
        AND to_date(PH.Rec_Doc_Date) >= to_date('2023-03-01')
        AND to_date(PH.Rec_Doc_Date) < to_date('2023-07-15')
        ) t3
where t3.indent_num = 'NA'
'''
df = spark.sql(query)
df.show()

df.write.format('parquet').mode('overwrite').save("s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/CHD_PO_3YRS_NOT_INDNT/")