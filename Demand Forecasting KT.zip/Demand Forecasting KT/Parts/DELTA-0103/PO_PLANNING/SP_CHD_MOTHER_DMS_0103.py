import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


df_pd_po = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PD_PO/').select(['PART_NUM', 'PO_QTY', 'PARENT_GROUP', 'DEALER_MAP_CD', 'LOC_CD', 'PO_NUM', 'PO_TYPE', 'COMP_FA', 'PO_SRL'])
#df_pd_po.cache()
df_pd_po.createOrReplaceTempView('PD_PO')
#df_pd_po.count()
df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/').select(['PARENT_GROUP', 'DEALER_MAP_CD', 'LOC_CD', 'REGION_CD', 'PARENT_GROUP', 'PRINCIPAL_MAP_CD', 'SPARES_STOCK_YARD_YN', 'CONSG_CD'])
#df_am_dealer_loc.cache()
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
#df_am_dealer_loc.count()
df_am_company_master = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/').select(['PARENT_GROUP', 'DEALER_MAP_CD'])
#df_am_company_master.cache()
df_am_company_master.createOrReplaceTempView('AM_COMPANY_MASTER')
#df_am_company_master.count()
df_ph_po = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PH_PO/').select(['SUPPLIER_CD', 'PO_NUM', 'PO_DATE', 'PARENT_GROUP', 'DEALER_MAP_CD', 'LOC_CD', 'PO_TYPE', 'COMP_FA', 'PO_DATE', 'PO_STATUS'])
#df_ph_po.cache()
df_ph_po.createOrReplaceTempView('PH_PO')
#df_ph_po.count()
df_pm_part = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/').select(['PART_NUM', 'DEALER_MAP_CD'])
#df_pm_part.cache()
df_pm_part.createOrReplaceTempView('PM_PART')
#df_pm_part.count()
df_open_po_cl = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.OPEN_PO_CL/').select(['ORDP_QTY', 'ORDE_REF_NO', 'ORDE_CONS_ID', 'ORDP_ITEM_CODE', 'STATUS', 'CREATED_DATE'])
#df_open_po_cl.cache()
df_open_po_cl.createOrReplaceTempView('OPEN_PO_CL')
#df_open_po_cl.count()


query = '''
SELECT
    'M' ROW_TRANS_TYPE,
    pd.part_num ITEM_CODE,
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
    AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    pd.Po_Num ORDER_NUM,
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD || '-' || pd.part_num || '-' || pd.Po_Num ORDER_LINE_NUM,
    date_format(current_date(), 'yyyyMMdd') || 'T' || date_format(current_date(), 'HHmm') EXTRACTION_DATE,
    current_timestamp() CREATED_DATE,
    PH.SUPPLIER_CD SUPP_CODE,
    ceil(GREATEST((pd.po_qty - NVL(
                            (SELECT 
                                SUM(PML1.ORDP_QTY)
                            FROM 
                                OPEN_PO_CL PML1
                            WHERE 
                                PML1.ORDE_REF_NO = PH.PO_NUM
                                AND PML1.ORDE_CONS_ID = AM.CONSG_CD
                                AND PML1.ORDP_ITEM_CODE = PD.PART_NUM
                                AND PML1.STATUS = 'CANCEL_DET'
                                AND TO_DATE(PML1.CREATED_DATE) >= to_date('2023-07-15')), 0)), 0)) ORDER_QTY,
    date_format(to_date(PO_DATE), 'yyyyMMdd') ORDER_DATE,
    0 RECVD_QTY,
    '' RECVD_DATE
    
FROM
    PH_PO ph,
    pd_po pd,
    AM_DEALER_LOC AM,
    AM_COMPANY_MASTER ma,
    PM_PART PP
WHERE 
    PH.PARENT_GROUP = PD.PARENT_GROUP
    AND PH.DEALER_MAP_CD = PD.DEALER_MAP_CD
    AND PH.LOC_CD = PD.LOC_CD
    AND PH.PO_NUM = PD.PO_NUM
    AND PH.PO_TYPE = PD.PO_TYPE
    AND PH.COMP_FA = PD.COMP_FA
    AND to_date(PH.PO_DATE) >= to_date('2023-03-01')
    AND to_date(PH.PO_DATE) < to_date('2023-07-15')
    AND PD.PO_SRL > 0
    AND PH.SUPPLIER_CD = 'MUL'
    AND PH.PO_STATUS = 'R'
    AND PH.PARENT_GROUP = AM.PARENT_GROUP
    AND AM.DEALER_MAP_CD = PH.DEALER_MAP_CD
    AND AM.LOC_CD = PH.LOC_CD
    AND AM.PRINCIPAL_MAP_CD = 1
    AND AM.SPARES_STOCK_YARD_YN = 'Y'
    and ma.parent_group = AM.parent_group
    and ma.dealer_map_cd = AM.dealer_map_cd
    AND PP.PART_NUM = PD.PART_NUM
    AND PP.DEALER_MAP_CD = 1
    AND NOT EXISTS
        (SELECT 1
         FROM OPEN_PO_CL op
         where op.status in ('EXPIRY_DET',
                             'ERROR_BATCH',
                             'INVOCE_DET')
             AND OP.ORDE_REF_NO = PD.PO_NUM
             AND OP.ORDP_ITEM_CODE = PD.PART_NUM
             AND OP.ORDE_CONS_ID = AM.CONSG_CD
             AND TO_DATE(OP.CREATED_DATE) >= to_date('2023-07-15'))
'''
df = spark.sql(query)
df.show()
df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA_0908/PO_PLANNING_TOOL_DELTA/MOTHER_3YRS_DMS_DELTA/')