##ORIGINAL with MOD

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext.getOrCreate()
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
df_AM_DEALER_LOC_PARAM = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC_PARAM/")
df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
DF_PM_PART_VAR = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_VAR/")
DF_pm_part_selection = spark.read.parquet("s3://msil-aos-processed/pm-part-selection/")
DF_pm_part = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
DF_am_acc_dealer_code_map = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_ACC_DEALER_CODE_MAP/")
 
DF_am_acc_dealer_code_map.createOrReplaceTempView("am_acc_dealer_code_map")    
df_AM_DEALER_LOC_PARAM.createOrReplaceTempView("AM_DEALER_LOC_PARAM")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
DF_PM_PART_VAR.createOrReplaceTempView("PM_PART_VAR")
DF_pm_part_selection.createOrReplaceTempView("pm_part_selection_poc")
DF_pm_part.createOrReplaceTempView("PM_PART")
df_gps = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA/GET_PARTS_SOURCE/').filter('jb="jb_sp_item_data"')
df_gps.createOrReplaceTempView('get_parts_source')

##ORIGINAL WITH FIRST
df_result = spark.sql("""(SELECT distinct 'M' Row_transaction_type,
                       'ITEM' Supplier_Data_Type,
                       PPV.PART_NUM PART_NUMBER,
                       '' PREFIX,
                       AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' ||
                       AM.LOC_CD WAREHOUSE_CODE,
                       AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GRP_CD,
                        CASE WHEN PM.CATG_CD <> 'AA' THEN
                       CASE
                         WHEN AM.SPARES_STOCK_YARD_YN = 'Y' THEN
                          (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
                         ELSE
                          (SELECT first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD)
                             FROM AM_DEALER_LOC AM1
                            WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP                                 
                              AND AM1.CONSG_CD = AM.CONSG_CD
                              AND AM1.SPARES_STOCK_YARD_YN = 'Y')
                              
                          END 
                       WHEN PM.CATG_CD = 'AA' THEN
                        CASE
                        WHEN AM.SPARES_STOCK_YARD_YN = 'Y' and
                       (am.consg_cd =
                       (SELECT FIRST(ac.acc_ordering_consignee)
                           from am_acc_dealer_code_map ac
                          where ac.loc_cd = am.loc_cd
                            and am.outlet_cd = ac.outlet_cd
                            and am.mul_dealer_cd = ac.dealer_cd
                            and am.principal_map_cd = 1) OR
                       ((SELECT FIRST(acc_ordering_consignee)
                            from am_acc_dealer_code_map ac
                           where ac.loc_cd = am.loc_cd
                             and am.outlet_cd = ac.outlet_cd
                             and am.mul_dealer_cd = ac.dealer_cd
                             and am.principal_map_cd = 1) IS NULL)) THEN
                                (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
                               WHEN AM.SPARES_STOCK_YARD_YN = 'Y' THEN
                            (SELECT FIRST(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' ||AM1.LOC_CD)
                               FROM AM_DEALER_LOC AM1, AM_ACC_DEALER_CODE_MAP AC1
                               WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP
                                AND AM1.CONSG_CD = AC1.Acc_ordering_consignee
                                AND AM1.SPARES_STOCK_YARD_YN = 'Y'
                                and am.loc_cd = ac1.loc_cd
                                and am.outlet_cd = ac1.outlet_cd
                                and am.mul_dealer_cd = ac1.dealer_cd
                                and am.principal_map_cd = 1 )
                            WHEN nvl(AM.SPARES_STOCK_YARD_YN, 'N') <> 'Y' and
                            am.loc_cd =
                            (SELECT FIRST(ac.loc_cd)
                            from am_acc_dealer_code_map ac
                            where ac.loc_cd = am.loc_cd
                            and am.outlet_cd = ac.outlet_cd
                            and am.mul_dealer_cd = ac.dealer_cd
                            and am.principal_map_cd = 1
                            and ac.acc_ordering_consignee is not null)
                            THEN
                            (SELECT FIRST(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' ||AM1.LOC_CD)
                              FROM AM_DEALER_LOC AM1, AM_ACC_DEALER_CODE_MAP AC1
                                WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP
                                AND AM1.CONSG_CD = AC1.Acc_ordering_consignee
                                AND AM1.SPARES_STOCK_YARD_YN = 'Y'
                                and am.loc_cd = ac1.loc_cd
                                and am.outlet_cd = ac1.outlet_cd
                                and am.mul_dealer_cd = ac1.dealer_cd
                                and am.principal_map_cd = 1
                            )
                            ELSE
                            (SELECT first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' ||AM1.LOC_CD)
                               FROM AM_DEALER_LOC AM1
                               WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP                         
                               AND AM1.CONSG_CD = AM.CONSG_CD
                               AND AM1.SPARES_STOCK_YARD_YN = 'Y')
                             END  
                            END SUPPLIER_CODE,

                       '' MARKET_CODE,
                       PPV.PART_NUM MASTER_ITEM_CODE,
                       CASE
                         WHEN AM.SPARES_STOCK_YARD_YN = 'Y' THEN
                          (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
                         ELSE
                          (SELECT first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD)
                             FROM AM_DEALER_LOC AM1
                            WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP                                 
                              AND AM1.CONSG_CD = AM.CONSG_CD
                              AND AM1.SPARES_STOCK_YARD_YN = 'Y')
                       END Master_Supplier_Code,
                       '' Hazardous,
                       '' Returnable,
                       '' Replacement,
                       '' Replacement_desc,
                       '' DELIVERY_MODE_CD,
                       DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE,
                       case
                         when CASE
                                WHEN AM.SPARES_STOCK_YARD_YN = 'Y' THEN
                                 (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
                                ELSE
                                 (SELECT first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD)
                                    FROM AM_DEALER_LOC AM1
                                   WHERE AM1.PARENT_GROUP = AM.PARENT_GROUP                                      
                                     AND AM1.CONSG_CD = AM.CONSG_CD
                                     AND AM1.SPARES_STOCK_YARD_YN = 'Y'                                  
                                  )
                              END = 'GGN' then
                            CASE
                                WHEN NVL(AP.MUL_LEAD_TIME, 1) = 0 THEN 1
                                ELSE NVL(AP.MUL_LEAD_TIME, 1)
                                END
                                ELSE
                                CASE
                                  WHEN AP.RPDC_LEAD_TIME IS NULL THEN
                                  CASE
                                    WHEN NVL(AP.MUL_LEAD_TIME, 1) = 0 THEN 1
                                    ELSE NVL(AP.MUL_LEAD_TIME, 1)
                                    END
                                    ELSE
                                    CASE
                                    WHEN NVL(AP.RPDC_LEAD_TIME, 1) = 0 THEN 1
                                    ELSE NVL(AP.RPDC_LEAD_TIME, 1)
                                    END
                                END
                       END as Lead_time,
                       ceil(PM.MIN_ORD_QTY) Minimum_order_qty,
                       99999 Maximum_order_qty,
                       ceil(PM.MIN_ORD_QTY) Multiple_order_qty,
                       '' Purchase_price,
                       '' Purchase_price_currency,
                       '' Duty_Cost,
                       '' Duty_Cost_Curr,
                       '' Other_Cost,
                       '' Other_Cost_Curr,
                       '' Transport_Cost,
                       '' Transport_Cost_Curr,
                       '' Free_Text1,
                       '' Free_Text2,
                       '' Bulk_Order_qty1,
                       '' Bulk_Order_qty2,
                       '' Discount_order_qty_limit1,
                       '' Discount_ordre_qty_limit2,
                       '' Discount_item_price1,
                       '' Discount_item_price_curr1,
                       '' Discount_item_price2,
                       '' Discount_item_price_curr2,
                       '' Use_Rev_trans_order,
                       '' Use_in_plan_event_order,
                       '' Supplier_email_address,
                       '' Supplier_item_code,
                       CURRENT_TIMESTAMP() Created_date
         FROM PM_PART_VAR           PPV,
              PM_PART               PM,
              AM_DEALER_LOC         AM,
              AM_DEALER_LOC_PARAM   AP,
              pm_part_selection_poc PPS
        WHERE PPV.PART_NUM = PM.PART_NUM
          AND PM.DEALER_MAP_CD = 1
          AND PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD
          AND PPV.LOC_CD = AM.LOC_CD
          AND PPV.PARENT_GROUP = AM.PARENT_GROUP
          AND AM.PRINCIPAL_MAP_CD = 1
          AND AM.Parent_Group = AP.Parent_Group
          AND AM.DEALER_MAP_CD = AP.DEALER_MAP_CD
          AND AM.LOC_CD = AP.LOC_CD
          AND AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
          AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
          AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
          AND PM.PART_NUM = PPS.Part_Num
          AND PM.CATG_CD NOT IN ('A', 'L', 'U', 'UA', 'OIL', 'T'
          ##and AM.parent_group = 'PRATH'
          ##and AM.dealer_map_cd = '10163'
          ##and AM.loc_cd IN ('ACC' , 'ANK' , 'BLL' , 'BLO' , 'CHM' , 'QRS' , 'RJI' , 'RJN' , 'SAJ' , 'SJP' , 'SRR' , 'TMH'))""")
df_result.show()