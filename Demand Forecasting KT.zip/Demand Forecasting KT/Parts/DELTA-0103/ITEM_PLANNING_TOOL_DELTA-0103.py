import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
from datetime import datetime as dt
import argparse
from pyspark.sql.utils import AnalysisException
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/')
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
df_pm_part = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/')
df_pm_part.createOrReplaceTempView('PM_PART')
df_pm_part_var = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_VAR/')
df_pm_part_var.createOrReplaceTempView('PM_PART_VAR')
df_pm_part_selection_poc = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PM_PART_SELECTION-0103/')
df_pm_part_selection_poc.createOrReplaceTempView('PM_PART_SELECTION_POC')
df_fin_acc_cd = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.FIN_ACC_CD/')
df_fin_acc_cd.createOrReplaceTempView('FIN_ACC_CD')
df_am_acc_dealer_code_map = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_ACC_DEALER_CODE_MAP/')
df_am_acc_dealer_code_map.createOrReplaceTempView('AM_ACC_DEALER_CODE_MAP')
df_pm_part_group = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_GROUP/')
df_pm_part_group.createOrReplaceTempView('PM_PART_GROUP')
df_am_list = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_LIST/')
df_am_list.createOrReplaceTempView('AM_LIST')
df_pm_category = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_CATEGORY/')
df_pm_category.createOrReplaceTempView('PM_CATEGORY')
df_part_wght_vol = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PART_WGHT_VOL/')
df_part_wght_vol.createOrReplaceTempView('PART_WGHT_VOL')
df_pm_part_source = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_SOURCE/')
df_pm_part_source.createOrReplaceTempView('PM_PART_SOURCE')
df_am_consignee = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_CONSIGNEE/')
df_am_consignee.createOrReplaceTempView('AM_CONSIGNEE')
df_gps = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/GET_PART_SOURCE-0103/').filter('jb="jb_sp_item_data"').select('d_map_cd', 'p_group', 'l_cd', 'partno', 'lv_source').distinct()
df_gps.createOrReplaceTempView('get_parts_source')



query_old = '''
with
get_al_list_code as (
    SELECT 
        al.LIST_CODE,
        ps.part_num,
        AM1.CONSG_CD,
        AM1.DEALER_MAP_CD,
        AM1.PARENT_GROUP,
        AM1.LOC_CD
    FROM 
        pm_part_source ps
        INNER JOIN 
            am_list al 
            ON ps.part_comp_cd = al.list_code
            AND ps.principal_map_cd = al.principal_map_cd
        INNER JOIN 
            am_consignee cn 
            ON al.list_code = cn.rpdc_status
            AND cn.principal_map_cd = al.principal_map_cd
        INNER JOIN 
            AM_DEALER_LOC AM1 
            ON cn.consg_cd = AM1.CONSG_CD
            AND cn.principal_map_cd = AM1.PRINCIPAL_MAP_CD
    WHERE 
        ps.serve_flag = 'Y'
        AND al.principal_map_cd = 1
        AND al.list_name = 'RPDC_SOURCE'
),
ppg_max_created_date as (
        SELECT
            DISTINCT
                PPV.PART_NUM,
                (select 
                    MAX(PPG.CREATED_DATE)
                FROM 
                    Pm_Part_Group PPG
                where 
                    PPG.PART_NUM = PPV.PART_NUM
                    AND PPG.PRINCIPAL_MAP_CD = 1
                ) max_created_date
        FROM
            PM_PART_VAR PPV
),
ppg1_group_cd AS (
    SELECT
        distinct
            PPG1.PART_NUM,
            PPG1.GROUP_CD
    FROM
        Pm_Part_Group PPG1
        join
            ppg_max_created_date
            on ppg_max_created_date.part_num = ppg_max_created_date.part_num
    WHERE    
        PPG1.PRINCIPAL_MAP_CD = 1
        AND PPG1.CREATED_DATE > ppg_max_created_date.max_created_date
)
SELECT 
    DISTINCT 
        T1.ROW_TRANS_TYPE ROW_TRANS_TYPE,
        T1.ITEM_CODE ITEM_CODE,
        T1.WAREHOUSE_CODE WAREHOUSE_CODE,
        T1.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
        T1.EXTRACTION_DATE EXTRACTION_DATE,
        T1.CREATED_DATE CREATED_DATE,
        T1.DESCRIPTION_ITEM DESCRIPTION_ITEM,
        T1.MASTER_ITEM_CODE MASTER_ITEM_CODE,
        T1.PREFERRED_SUPPLIER_CODE PREF_SUPP_CODE,
        --TO_CHAR(T1.ACTIVATION_DATE, 'YYYYMMDD') ACTIVATION_DATE,
        date_format(TO_DATE(T1.ACTIVATION_DATE), 'yyyyMMdd') as ACTIVATION_DATE,
        --TO_CHAR(T1.DEACTIVATION_DATE, 'YYYYMMDD') DEACTIVATION_DATE,
        date_format(TO_DATE(T1.DEACTIVATION_DATE), 'yyyyMMdd') as DEACTIVATION_DATE,
        --TRUNC(DECODE(T1.UNIT_COST, 0, NULL, T1.UNIT_COST), 2) UNIT_COST,
        IF(T1.UNIT_COST = 0, NULL, round(T1.UNIT_COST, 2)) UNIT_COST,
        --DECODE(T1.UNIT_COST, NULL, NULL, 0, NULL, 'INR') UNIT_COST_CURR,
        CASE WHEN T1.UNIT_COST IS NULL THEN NULL 
            WHEN T1.UNIT_COST = 0 THEN NULL 
            ELSE 'INR' 
        END AS UNIT_COST_CURR,
        SELECT 
  ROUND(
    CASE 
      WHEN T1.WEIGHT = 0 THEN NULL 
      ELSE T1.WEIGHT 
    END,
    2
  ) WEIGHT,
  
  CASE
    WHEN T1.WEIGHT = 0 THEN NULL
    ELSE
      CASE 
        WHEN T1.WEIGHT IS NULL THEN NULL
        ELSE 'kg'
      END,
  END AS WEIGHT_UOM,
  
  CASE 
    WHEN T1.VOLUME = 0 THEN NULL 
    ELSE T1.VOLUME 
  END AS VOLUME,
  
  CASE
    WHEN T1.VOLUME = 0 THEN NULL
    ELSE
      CASE 
        WHEN T1.VOLUME IS NULL THEN NULL
        ELSE 'cm3'
      END
  END AS VOLUME_UOM,

       
        T1.UOM UOM,
        T1.ITEM_GP_1 ITEM_GP_1,
        T1.ITEM_GP_2 ITEM_GP_2,
        T1.FREE_TEXT_1 ROOT_NUM_FT1,
        T1.FREE_TEXT_2 ISS_IND_FT2,
        T1.FREE_TEXT_3 CONS_CD_FT3,
        T1.FREE_TEXT_4 DEL_CD_FT4,
        T1.FREE_TEXT_5 ACC_CD_FT5,
        T1.FREE_TEXT_6 MUL_CD_FT6,
        T1.FREE_TEXT_7 FREE_TEXT_7
FROM
(
SELECT
    'M' ROW_TRANS_TYPE,
    PM.PART_NUM ITEM_CODE,
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
    AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    date_format(current_timestamp(), 'yyyyMMdd') || 'T' || date_format(current_timestamp(), 'HHmm') EXTRACTION_DATE,
    current_date() CREATED_DATE,
    replace(PM.PART_DESC,chr(124),chr(47)) DESCRIPTION_ITEM,
    PM.PART_NUM MASTER_ITEM_CODE,
    CASE
        WHEN 
            AM.SPARES_STOCK_YARD_YN = 'Y' 
            THEN 
                (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
        ELSE
            (SELECT 
                first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD)
            FROM 
                AM_DEALER_LOC AM1
            WHERE 
                AM1.PARENT_GROUP = AM.PARENT_GROUP
                AND AM1.CONSG_CD = AM.CONSG_CD
                AND AM1.SPARES_STOCK_YARD_YN = 'Y')
    END PREFERRED_SUPPLIER_CODE,
    COALESCE(PM.EFF_FROM_DATE,PM.CREATED_DATE) ACTIVATION_DATE,
    PM.CLOSED_DATE DEACTIVATION_DATE,
    PPV.Purchase_Price UNIT_COST,
    (select 
        (first(pw.mdim_i_weight) / 1000)
    from 
        PART_WGHT_VOL pw
    where 
        pw.mdim_item_code = PM.PART_NUM
        AND PW.MDIM_COMP_CODE = COALESCE(galc.list_code,'01')
    ) WEIGHT,
    (select 
        (first(pw.mdim_i_length) * first(pw.mdim_i_width) * first(pw.mdim_i_height))
    from 
        PART_WGHT_VOL pw
    where 
        pw.mdim_item_code = PM.PART_NUM
        AND PW.MDIM_COMP_CODE = COALESCE(galc.list_code,'01')
    ) VOLUME,
    PM.UOM_CD UOM,
    (SELECT 
        first(PC.CATG_DESC)
    FROM 
        PM_CATEGORY PC
    WHERE 
        PC.PRINCIPAL_MAP_CD = 1
        AND PC.CATG_CD = PM.CATG_CD
    ) ITEM_GP_1,
    (select 
        FIRST(AM1.LIST_DESC)
    from 
        am_list am1
    where 
        AM1.LIST_NAME = 'PART_TYPE'
        AND AM1.PRINCIPAL_MAP_CD = 1
        AND am1.list_code = ppg1_group_cd.group_cd
    ) ITEM_GP_2,
    PM.ROOT_PART_NUM FREE_TEXT_1,
    PM.TAG_CD FREE_TEXT_2,
    AM.CONSG_CD FREE_TEXT_3,
    AM.MUL_DEALER_CD FREE_TEXT_4,
    (SELECT 
        first(AC.ACC_CODE)
    FROM 
        am_acc_dealer_code_map ac
    WHERE 
        AC.DEALER_CD = AM.Mul_Dealer_Cd
        AND AC.Outlet_Cd = AM.Outlet_Cd
        AND AC.LOC_CD = AM.LOC_CD
    ) FREE_TEXT_5,
    (select 
       CASE 
            WHEN 
                first(FAC.CUST_ACC_ID) IS NULL 
            THEN 
                first(FAC.CONSIGNEE_CODE)
        ELSE 
            first(FAC.CUST_ACC_ID) 
      END CUSTOMER_ACCOUNT_ID
    from 
        FIN_ACC_CD FAC
    WHERE 
        FAC.CONSIGNEE_CODE = AM.CONSG_CD
    ) MUL_CD_FT6,
    PPV.LANDED_COST FREE_TEXT_7
from
    PM_PART_VAR PPV
    join 
        AM_DEALER_LOC AM
        ON  PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD
        AND PPV.LOC_CD = AM.LOC_CD
        AND PPV.PARENT_GROUP = AM.PARENT_GROUP
        AND AM.PRINCIPAL_MAP_CD = 1
    join
        PM_PART_SELECTION_POC PPS
        ON  PPV.PART_NUM = PPS.PART_NUM
        AND AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
        AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
        AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
    CROSS JOIN
        PM_PART PM
    left join
        get_al_list_code galc
        on  galc.part_num = PM.PART_NUM
        and galc.CONSG_CD = AM.CONSG_CD
        and galc.DEALER_MAP_CD = AM.DEALER_MAP_CD
        and galc.PARENT_GROUP = AM.PARENT_GROUP
        and galc.LOC_CD = AM.LOC_CD
    LEFT JOIN
        ppg1_group_cd
        ON ppg1_group_cd.PART_NUM=PPV.PART_NUM
WHERE 
    PPV.PART_NUM = PM.PART_NUM
    AND PM.DEALER_MAP_CD = 1
    --AND PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD
    --AND PPV.LOC_CD = AM.LOC_CD
    --AND PPV.PARENT_GROUP = AM.PARENT_GROUP
    --AND AM.PRINCIPAL_MAP_CD = 1
    AND PM.CATG_CD NOT IN ('A', 'L', 'U', 'UA', 'OIL', 'T')
    --AND PPV.PART_NUM = PPS.PART_NUM
    --AND AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
    --AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
    --AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
)  T1
'''


query = '''
with
get_al_list_code as (
    SELECT 
        al.LIST_CODE,
        ps.part_num,
        AM1.CONSG_CD,
        AM1.DEALER_MAP_CD,
        AM1.PARENT_GROUP,
        AM1.LOC_CD
    FROM 
        pm_part_source ps
        INNER JOIN 
            am_list al 
            ON ps.part_comp_cd = al.list_code
            AND ps.principal_map_cd = al.principal_map_cd
        INNER JOIN 
            am_consignee cn 
            ON al.list_code = cn.rpdc_status
            AND cn.principal_map_cd = al.principal_map_cd
        INNER JOIN 
            AM_DEALER_LOC AM1 
            ON cn.consg_cd = AM1.CONSG_CD
            AND cn.principal_map_cd = AM1.PRINCIPAL_MAP_CD
    WHERE 
        ps.serve_flag = 'Y'
        AND al.principal_map_cd = 1
        AND al.list_name = 'RPDC_SOURCE'
),
ppg1 AS (
    select
        distinct
            part_num,
            GROUP_CD,
            PRINCIPAL_MAP_CD
FROM
     (select
          part_num,
          GROUP_CD,
          CREATED_DATE,
          PRINCIPAL_MAP_CD,
          max(CREATED_DATE) over(partition by part_num) max_created_date
     from Pm_Part_Group) ppg
where
    ppg.created_date >= ppg.max_created_date
)
SELECT 
    DISTINCT 
        T1.ROW_TRANS_TYPE ROW_TRANS_TYPE,
        T1.ITEM_CODE ITEM_CODE,
        T1.WAREHOUSE_CODE WAREHOUSE_CODE,
        T1.WAREHOUSE_GROUP_CODE WAREHOUSE_GROUP_CODE,
        T1.EXTRACTION_DATE EXTRACTION_DATE,
        T1.CREATED_DATE CREATED_DATE,
        T1.DESCRIPTION_ITEM DESCRIPTION_ITEM,
        T1.MASTER_ITEM_CODE MASTER_ITEM_CODE,
        T1.PREFERRED_SUPPLIER_CODE PREF_SUPP_CODE,
        --TO_CHAR(T1.ACTIVATION_DATE, 'YYYYMMDD') ACTIVATION_DATE,
        date_format(TO_DATE(T1.ACTIVATION_DATE), 'yyyyMMdd') as ACTIVATION_DATE,
        --TO_CHAR(T1.DEACTIVATION_DATE, 'YYYYMMDD') DEACTIVATION_DATE,
        date_format(TO_DATE(T1.DEACTIVATION_DATE), 'yyyyMMdd') as DEACTIVATION_DATE,
        --TRUNC(DECODE(T1.UNIT_COST, 0, NULL, T1.UNIT_COST), 2) UNIT_COST,
        IF(T1.UNIT_COST = 0, NULL, round(T1.UNIT_COST, 2)) UNIT_COST,
        --DECODE(T1.UNIT_COST, NULL, NULL, 0, NULL, 'INR') UNIT_COST_CURR,
        CASE WHEN T1.UNIT_COST IS NULL THEN NULL 
            WHEN T1.UNIT_COST = 0 THEN NULL 
            ELSE 'INR' 
        END AS UNIT_COST_CURR,
    ROUND(                                                                   
         CASE
            WHEN T1.WEIGHT = 0 THEN NULL
            ELSE T1.WEIGHT
         END,
         2
         )WEIGHT,                                                                      
    CASE WHEN T1.WEIGHT = 0 THEN NULL
         ELSE
            CASE WHEN T1.WEIGHT IS NULL THEN NULL
                 ELSE 'kg'
            END
    END AS WEIGHT_UOM, 
    CASE WHEN T1.VOLUME = 0 THEN NULL
         ELSE T1.VOLUME
    END AS VOLUME, 
    CASE WHEN T1.VOLUME = 0 THEN NULL
         ELSE
            CASE WHEN T1.VOLUME IS NULL THEN NULL
                 ELSE 'cm3'
            END
    END AS VOLUME_UOM,
    T1.UOM UOM,
    T1.ITEM_GP_1 ITEM_GP_1,
    T1.ITEM_GP_2 ITEM_GP_2,
    T1.FREE_TEXT_1 ROOT_NUM_FT1,
    T1.FREE_TEXT_2 ISS_IND_FT2,
    T1.FREE_TEXT_3 CONS_CD_FT3,
    T1.FREE_TEXT_4 DEL_CD_FT4,
    T1.FREE_TEXT_5 ACC_CD_FT5,
    T1.FREE_TEXT_6 MUL_CD_FT6,
    T1.FREE_TEXT_7 FREE_TEXT_7
FROM
(
SELECT
    'M' ROW_TRANS_TYPE,
    PM.PART_NUM ITEM_CODE,
    AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
    AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    date_format(current_timestamp(), 'yyyyMMdd') || 'T' || date_format(current_timestamp(), 'HHmm') EXTRACTION_DATE,
    current_date() CREATED_DATE,
    replace(PM.PART_DESC,chr(124),chr(47)) DESCRIPTION_ITEM,
    PM.PART_NUM MASTER_ITEM_CODE,
    CASE
        WHEN 
            AM.SPARES_STOCK_YARD_YN = 'Y' 
            THEN 
                (select first(lv_source) from get_parts_source gps where gps.d_map_cd=AM.DEALER_MAP_CD and gps.p_group=AM.PARENT_GROUP and gps.l_cd=AM.LOC_CD and gps.partno=PM.PART_NUM)
        ELSE
            (SELECT 
                first(AM1.PARENT_GROUP || '-' || AM1.DEALER_MAP_CD || '-' || AM1.LOC_CD)
            FROM 
                AM_DEALER_LOC AM1
            WHERE 
                AM1.PARENT_GROUP = AM.PARENT_GROUP
                AND AM1.CONSG_CD = AM.CONSG_CD
                AND AM1.SPARES_STOCK_YARD_YN = 'Y')
    END PREFERRED_SUPPLIER_CODE,
    COALESCE(PM.EFF_FROM_DATE,PM.CREATED_DATE) ACTIVATION_DATE,
    PM.CLOSED_DATE DEACTIVATION_DATE,
    PPV.Purchase_Price UNIT_COST,
    (select 
        (first(pw.mdim_i_weight) / 1000)
    from 
        PART_WGHT_VOL pw
    where 
        pw.mdim_item_code = PM.PART_NUM
        AND PW.MDIM_COMP_CODE = COALESCE(galc.list_code,'01')
    ) WEIGHT,
    (select 
        (first(pw.mdim_i_length) * first(pw.mdim_i_width) * first(pw.mdim_i_height))
    from 
        PART_WGHT_VOL pw
    where 
        pw.mdim_item_code = PM.PART_NUM
        AND PW.MDIM_COMP_CODE =COALESCE(galc.list_code,'01')
    ) VOLUME,
    PM.UOM_CD UOM,
    (SELECT 
        first(PC.CATG_DESC)
    FROM 
        PM_CATEGORY PC
    WHERE 
        PC.PRINCIPAL_MAP_CD = 1
        AND PC.CATG_CD = PM.CATG_CD
    ) ITEM_GP_1,
    (select 
        FIRST(AM1.LIST_DESC)
    from 
        am_list am1
    where 
        AM1.LIST_NAME = 'PART_TYPE'
        AND AM1.PRINCIPAL_MAP_CD = 1
        AND am1.list_code = ppg1.group_cd
    ) ITEM_GP_2,
    PM.ROOT_PART_NUM FREE_TEXT_1,
    PM.TAG_CD FREE_TEXT_2,
    AM.CONSG_CD FREE_TEXT_3,
    AM.MUL_DEALER_CD FREE_TEXT_4,
    (SELECT 
        first(AC.ACC_CODE)
    FROM 
        am_acc_dealer_code_map ac
    WHERE 
        AC.DEALER_CD = AM.Mul_Dealer_Cd
        AND AC.Outlet_Cd = AM.Outlet_Cd
        AND AC.LOC_CD = AM.LOC_CD
    ) FREE_TEXT_5,
     (select 
       CASE 
            WHEN 
                first(FAC.CUST_ACC_ID) IS NULL 
            THEN 
                first(FAC.CONSIGNEE_CODE)
        ELSE 
            first(FAC.CUST_ACC_ID) 
      END CUSTOMER_ACCOUNT_ID
    from 
        FIN_ACC_CD FAC
    WHERE 
        FAC.CONSIGNEE_CODE = AM.CONSG_CD
    ) FREE_TEXT_6,
    PPV.LANDED_COST FREE_TEXT_7
from
    PM_PART_VAR PPV
    join 
        AM_DEALER_LOC AM
        ON  PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD
        AND PPV.LOC_CD = AM.LOC_CD
        AND PPV.PARENT_GROUP = AM.PARENT_GROUP
        AND AM.PRINCIPAL_MAP_CD = 1
    join
        PM_PART_SELECTION_POC PPS
        ON  PPV.PART_NUM = PPS.PART_NUM
        AND AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
        AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
        AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
    CROSS JOIN
        PM_PART PM
    left join
        get_al_list_code galc
        on  galc.part_num = PM.PART_NUM
        and galc.CONSG_CD = AM.CONSG_CD
        and galc.DEALER_MAP_CD = AM.DEALER_MAP_CD
        and galc.PARENT_GROUP = AM.PARENT_GROUP
        and galc.LOC_CD = AM.LOC_CD
    LEFT JOIN
        ppg1
        ON ppg1.PART_NUM=PPV.PART_NUM
WHERE 
    PPV.PART_NUM = PM.PART_NUM
    AND PM.DEALER_MAP_CD = 1
    --AND PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD
    --AND PPV.LOC_CD = AM.LOC_CD
    --AND PPV.PARENT_GROUP = AM.PARENT_GROUP
    --AND AM.PRINCIPAL_MAP_CD = 1
    AND PM.CATG_CD NOT IN ('A', 'L', 'U', 'UA', 'OIL', 'T')
    --AND PPV.PART_NUM = PPS.PART_NUM
    --AND AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
    --AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
    --AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
)  T1
'''

df = spark.sql(query)
df.show()
df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA_0908/ITEM_PLANNING_TOOL_DELTA-0103/')