import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }



#df_PT_CBO_AOS= spark.read.jdbc(url=jdbc_url4, table="(SELECT * FROM MULDMS.PT_CBO_AOS )", properties=connection_details)
#DF_pm_part_selection = spark.read.jdbc(url=jdbc_url4, table="(SELECT * FROM MULDMS.pm_part_selection_temp )", properties=connection_details)


df_PT_CBO_AOS = spark.read.parquet("s3://msil-aos-processed/DELTA/PT_CBO_AOS/")   ##fetched from last processed job
df_PM_STOCK_BIN_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_STOCK_BIN_LOC/")
df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
DF_PM_PART_VAR = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_VAR/")
DF_PM_PART=spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")

DF_pm_part_selection = spark.read.parquet("s3://msil-aos-processed/DELTA_0908/PM_PART_SELECTION-0103/")
DF_PM_PART_DISP_STOCK = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_DISP_STOCK/")


df_PT_CBO_AOS.createOrReplaceTempView("PT_CBO_AOS")
df_PM_STOCK_BIN_LOC.createOrReplaceTempView("PM_STOCK_BIN_LOC")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
DF_PM_PART_VAR.createOrReplaceTempView("PM_PART_VAR")
DF_PM_PART.createOrReplaceTempView("PM_PART")
DF_pm_part_selection.createOrReplaceTempView("pm_part_selection_temp")
DF_PM_PART_DISP_STOCK.createOrReplaceTempView("PM_PART_DISP_STOCK")


df_result = spark.sql("""(SELECT 'M' ROW_TRANS_TYPE,
             PM.PART_NUM ITEM_CODE,
             '' PREFIX,
             AM.PARENT_GROUP || '-' || AM.DEALER_MAP_CD || '-' || AM.LOC_CD WAREHOUSE_CODE,
             AM.REGION_CD || '_' || AM.PARENT_GROUP WAREHOUSE_GROUP_CODE,
             DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS EXTRACTION_DATE, 
             CURRENT_TIMESTAMP() CREATED_DATE,
             (greatest(nvl(SUM(NVL(NVL(os_stock_qty, 0) +
                                        NVL(ls_stock_qty, 0) -
                                        (NVL(os_float_qty, 0) +
                                         NVL(ls_float_qty, 0) +
                                         NVL(alloc_qty, 0) +
                                         NVL(ws_resrv_qty, 0)),
                                        0)),
                                0),
                            0)) CURRENT_STOCK,
             '' OUTSTAND_ORD_QTY,
             '' TOTAL_BK_ORD,
             '' IN_TRANS_STK,
             (nvl(PD.PART_QTY, 0) + nvl(ppv.quarantine_qty, 0)) RESERVED_STK,
             '' BINNING_STK,
             nvl(ppv.quarantine_qty, 0) QUAR_STK_FT1,
             nvl(PD.PART_QTY, 0) DISP_STK_FT2,
             nvl(ppv.Resrv_Qty, 0) RESRV_STK_FT3,
             nvl(pm.alloc_qty, 0) ALL_STK_FT4,
             '' FREE_TEXT_5
                FROM PM_STOCK_BIN_LOC PM
					JOIN AM_DEALER_LOC AM ON PM.DEALER_MAP_CD = AM.DEALER_MAP_CD AND PM.LOC_CD = AM.LOC_CD AND PM.PARENT_GROUP = AM.PARENT_GROUP
					JOIN PM_PART_VAR PPV ON PPV.PART_NUM = PM.PART_NUM AND PPV.DEALER_MAP_CD = AM.DEALER_MAP_CD AND PPV.LOC_CD = AM.LOC_CD AND PPV.PARENT_GROUP = AM.PARENT_GROUP
                    JOIN PM_PART PPM ON PPV.PART_NUM = PPM.PART_NUM
					LEFT JOIN PM_PART_DISP_STOCK PD ON PD.PART_NUM = PM.PART_NUM AND PD.DEALER_MAP_CD = PM.DEALER_MAP_CD AND PD.LOC_CD = PM.LOC_CD AND PD.PARENT_GROUP = PM.PARENT_GROUP
					JOIN (SELECT DISTINCT part_num, warehouse_code FROM pm_part_selection_temp) pps ON PPV.PART_NUM = PPS.PART_NUM
					WHERE coalesce(PM.ACTIVE_YN, 'N') = 'Y'
					AND coalesce(PM.DEFAULT_YN, 'N') = 'Y'
					AND AM.PRINCIPAL_MAP_CD = 1
                    AND PPM.DEALER_MAP_CD = 1
					AND AM.PARENT_GROUP = element_at(split(PPS.warehouse_code, '-'), 1)
					AND AM.DEALER_MAP_CD = element_at(split(PPS.warehouse_code, '-'), 2)
					AND AM.LOC_CD = element_at(split(PPS.warehouse_code, '-'), 3)
                    AND PPM.CATG_CD NOT IN ('A', 'L', 'U', 'UA', 'OIL', 'T')
					
                
                GROUP BY PM.PART_NUM,
                    AM.REGION_CD,
                    AM.DEALER_MAP_CD,
                    AM.LOC_CD,
                    AM.PARENT_GROUP,
                    NVL(ppv.quarantine_qty,0),
                    NVL(PD.PART_QTY,0),
                    NVL(ppv.Resrv_Qty,0),
                    NVL(pm.alloc_qty,0))""")
				


from pyspark.sql.functions import ceil

df_result = df_result.withColumn("CURRENT_STOCK", ceil(df_result["CURRENT_STOCK"]))	
df_result = df_result.withColumn("TOTAL_BK_ORD", ceil(df_result["TOTAL_BK_ORD"]))	
df_result = df_result.withColumn("RESERVED_STK", ceil(df_result["RESERVED_STK"]))		
df_result = df_result.withColumn("QUAR_STK_FT1", ceil(df_result["QUAR_STK_FT1"]))	
df_result = df_result.withColumn("DISP_STK_FT2", ceil(df_result["DISP_STK_FT2"]))	
df_result = df_result.withColumn("RESRV_STK_FT3", ceil(df_result["RESRV_STK_FT3"]))
df_result = df_result.withColumn("ALL_STK_FT4", ceil(df_result["ALL_STK_FT4"]))



df_result.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/DELTA/STOCK_PLANNING_DELTA/")