import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

df_pm_part_selection = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/PM_PART_SELECTION-0103/')
df_pm_part_selection.createOrReplaceTempView('PM_PART_SELECTION')
df_pm_part_source = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_SOURCE/')
df_pm_part_source.createOrReplaceTempView('PM_PART_SOURCE')
df_am_dealer_loc = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/')
df_am_dealer_loc.createOrReplaceTempView('AM_DEALER_LOC')
df_am_list = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_LIST/')
df_am_list.createOrReplaceTempView('AM_LIST')
df_am_consignee = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.AM_CONSIGNEE/')
df_am_consignee.createOrReplaceTempView('AM_CONSIGNEE')
df_item_detl_link = spark.read.format('parquet').load('s3://msil-aos-raw/qlik-data/MULDMS.ITEM_DETL_LINK/')
df_item_detl_link.createOrReplaceTempView('ITEM_DETL_LINK')


#lookup
df_gps = spark.read.format('parquet').load('s3://msil-aos-processed/DELTA_0908/GET_PART_SOURCE-0103/').filter("jb='jb_sp_replace_planning_tool'")
df_gps.createOrReplaceTempView('get_parts_source')


query = '''
select 
    'M' ROW_TRANS_TYPE,
    T4.LATEST_PART RELPACING_ITEM_CODE,
    '' RELPACING_PREFIX,
    T1.PART_NUM RELPACED_ITEM_CODE,
    '' RELPACED_PREFIX,
    t1.PARENT_GROUP || '-' || t1.Dealer_Map_Cd || '-' || t1.LOC_CD WAREHOUSE_CODE,
    (select 
        first(am.region_cd)
    from 
        am_dealer_loc am
    where 
        am.parent_group = t1.PARENT_GROUP
        and am.dealer_map_cd = t1.DEALER_MAP_CD
        and am.loc_cd = t1.LOC_CD) || '_' || t1.PARENT_GROUP WAREHOUSE_GROUP_CODE,
    --to_char(sysdate, 'YYYYMMDD') || 'T' || to_char(sysdate, 'HH24MI') EXTRACTION_DATE,
    CONCAT(date_format(current_timestamp(),'yyyyMMdd'),'T',date_format(current_timestamp(),'HHmm')) EXTRACTION_DATE,
    --sysdate CREATED_DATE,
    current_date() CREATED_DATE,
    'Y' INHERIT_STOCK,
    1 REPLACEMENT_MULTIPLIER,
    'NULL' REPLACEMENT_DESCRIPTION,
    T4.ITEM_ISSUE_IND FREE_TEXT_1,
    '' FREE_TEXT_2
from 
    (SELECT 
        distinct 
            PPS.PART_NUM,
            PPS.WAREHOUSE_CODE,
            regexp_extract(Pps.warehouse_code, '([^-]+)', 1) PARENT_GROUP,
            regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2) DEALER_MAP_CD,
            regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3) LOC_CD,
            (SELECT 
                first(al.list_code)
            FROM 
                AM_LIST al
            WHERE 
                al.principal_map_cd = 1
                and al.list_name = 'RPDC_SOURCE'
                and al.list_desc = gps.lv_source
            ) List_Cd
    FROM 
        PM_PART_SELECTION PPS, AM_DEALER_LOC AM
    left join
        get_parts_source gps
        on  am.dealer_map_cd=gps.d_map_cd
        and am.parent_group=gps.p_group
        and am.loc_cd=gps.l_cd
        and PPS.PART_NUM=gps.partno
    WHERE 
        AM.PARENT_GROUP = regexp_extract(Pps.warehouse_code, '([^-]+)', 1)
        AND AM.DEALER_MAP_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)', 2)
        AND AM.LOC_CD = regexp_extract(Pps.warehouse_code, '([^-]+)-([^-]+)-([^-]+)', 3)
        AND Am.Principal_Map_Cd = 1
      --AND AM.CONSG_CD = '0211'
    ) t1,
    ITEM_DETL_LINK T4
where 
    t1.PART_NUM = t4.item_code
    and cast(t1.List_Cd as string) = t4.item_comp_code
'''

df = spark.sql(query)
df.show()
df.write.format('parquet').mode('overwrite').save('s3://msil-aos-processed/DELTA_0908/REPLACEMENT_PLANNING_TOOL_DELTA-0103/')