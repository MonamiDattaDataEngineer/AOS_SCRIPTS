from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")


PH_BOM = spark.read.format('parquet').load("s3:/msil-aos-procesed/PH_BOM")
PH_BOM.createOrReplaceTempView("PH_BOM")


select ph.row_type,
             Ph.Bom_Item_Code Item_Code,
             '' Prefix,
             ph.cluster_code warehouse_code,
             '' Warehouse_grp_cd,
             to_char(ph.as_on_date, 'yyyymm') Period,             
             to_char(sysdate, 'YYYYMMDD') || 'T' ||
             to_char(sysdate, 'HH24MI') Extraction_date,            
             sum(ph.veh_retail) Demand,
             sum(ph.veh_retail) No_Of_Picks,
             '' Back_Orders ,
             '' Free_Text1,
             '' Free_Text2,
             '' Free_Text3,
             '' Direct_demand,
             '' No_of_Direct_Picks
        from PH_VEH_RET_IFP ph
      group by ph.row_type,
       ph.bom_item_code,
                ph.cluster_code,                                               
                to_char(ph.as_on_date, 'yyyymm')