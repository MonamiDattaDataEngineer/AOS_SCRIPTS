from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

PH_ITEM_FAIL_PROFILE = spark.read.format('parquet').load("s3:/msil-aos-procesed/PH_ITEM_FAIL_PROFILE")
PH_ITEM_FAIL_PROFILE.createOrReplaceTempView("PH_ITEM_FAIL_PROFILE")


df = spark.sql('''(      select ph.row_type,
             ph.bom_item_code,
             '' Main_Item_Prefix,
             ph.item_code,
             '' Com_Item_Prefix,
             ph.cluster_code,
             '' Warehouse_grp_cd,
             ph.extraction_date,
             '' Comments,
             '' Free_Text1,
             '' Free_Text2,
             1 Quantity
        from PH_ITEM_FAIL_PROFILE ph
       where ph.mean_cas_fail_l12m is not null
         and ph.mean_cas_fail_l12m <> 0)''')
		 
df.write.format('parquet').save("s3/PH_BOM")		 
		 
		 