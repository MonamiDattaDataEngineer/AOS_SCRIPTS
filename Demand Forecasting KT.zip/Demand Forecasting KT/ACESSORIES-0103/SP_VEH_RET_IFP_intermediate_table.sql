import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")



SH_INVOICE = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.SH_INVOICE")
df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
DF_ACC_DEALER_CODE_MAP_CD = spark.read.parquet('s3://msil-aos-raw/qlik-data/MULDMS.AM_ACC_DEALER_CODE_MAP/')
DF_GM_CITY = 
DF_GM_VIN =
DF_PM_ACC_WEB_VAR_MAP

DF_GM_CITY.createOrReplaceTempView("gm_city")
DF_ACC_DEALER_CODE_MAP_CD.createOrReplaceTempView("am_acc_dealer_code_map")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
DF_SH_INVOICE.createOrReplaceTempView("SH_INVOICE")
DF_GM_VIN.createOrReplaceTempView("gm.vin")
DF_PM_ACC_WEB_VAR_MAP.createOrReplaceTempView("pm_acc_web_var_map")




df = spark.sql('''(SELECT Row_Type,
             Item_code,
             Prefix,
             replace(Bom_Item_Code, ' ', '-') Bom_Item_Code,
             Bom_Prefix,
             Cluster_Code,
             Warehouse_Grp_Cd,
             Causal_Factor,
             SUM(VERD_RETL_SH) - SUM(VERD_RETL_SH_CAN) VERD_RETL_SH,
             Casual_Factor_Weight,
             As_on_date
        FROM (SELECT 'M' Row_Type,
                     '' Item_code,
                     '' Prefix,
                     pa.model_code || '-' || pa.model_variant_code Bom_Item_Code,
                     '' Bom_Prefix,
                     ac.acc_code Cluster_Code,
                     '' Warehouse_Grp_Cd,
                     'CAR_SALES' Causal_Factor,
                     COUNT(1) VERD_RETL_SH,
                     0 VERD_RETL_SH_CAN,
                     1 Casual_Factor_Weight,
                     trunc(sh.inv_date) As_on_date
                FROM SH_INVOICE             SH,
                     AM_DEALER_LOC          AL,
                     AM_ACC_DEALER_CODE_MAP AC,
                     Gm_City                gm,
                     GM_VIN                 GV,
                     PM_ACC_WEB_VAR_MAP     PA
               WHERE AL.PRINCIPAL_MAP_CD = 1
                 AND AL.DEALER_MAP_CD = SH.DEALER_MAP_CD
                 AND AL.LOC_CD = SH.LOC_CD
                 AND SH.BILL_NATURE IN ('V', 'VC')
                 AND (SH.INV_DATE) >= P_FROM_DATE
                 AND (SH.INV_DATE) < P_TO_DATE
                 AND AL.city_cd = GM.City_Cd
                 and AL.Principal_Map_Cd = gm.principal_map_cd
                 AND AC.DEALER_CD = AL.Mul_Dealer_Cd
                 AND AC.Outlet_Cd = AL.Outlet_Cd
                 AND AL.Principal_Map_Cd = 1
                 AND SH.Vin = GV.VIN
                 AND GV.VARIANT_CD = PA.DMS_VARIANT
                 AND GV.Principal_Map_Cd = 1
                 and al.dealer_type in ('S','2S','3S')
                
               GROUP BY ac.acc_code,
                        pa.model_code,
                        pa.model_variant_code,
                        sh.inv_date
              UNION ALL
              SELECT 'M' Row_Type,
                     '' Item_code,
                     '' Prefix,
                     pa.model_code || '-' || pa.model_variant_code Bom_Item_Code,
                     '' Bom_Prefix,
                     ac.acc_code Cluster_Code,
                     '' Warehouse_Grp_Cd,
                     'CAR_SALES' Causal_Factor,
                     0 VERD_RETL_SH,
                     COUNT(1) VERD_RETL_SH_CAN,
                     1 Casual_Factor_Weight,
                     trunc(sh.cancel_date) As_on_date
                FROM SH_INVOICE             SH,
                     AM_DEALER_LOC          AL,
                     AM_ACC_DEALER_CODE_MAP AC,
                     gm_city                gm,
                     PM_ACC_WEB_VAR_MAP     PA
               WHERE AL.PRINCIPAL_MAP_CD = 1
                 AND AL.DEALER_MAP_CD = SH.DEALER_MAP_CD
                 AND AL.LOC_CD = SH.LOC_CD
                 AND SH.BILL_NATURE IN ('V', 'VC')
                 AND SH.CANCEL_DATE >= P_FROM_DATE
                 AND SH.CANCEL_DATE < P_TO_DATE
                    -- AND SH.CANCEL_DATE >= '01-JAN-2021'
                    -- AND SH.CANCEL_DATE < '01-FEB-2021'
                 AND AL.city_cd = GM.City_Cd
                 and AL.Principal_Map_Cd = gm.principal_map_cd
                 AND AC.DEALER_CD = AL.Mul_Dealer_Cd
                 AND AC.Outlet_Cd = AL.Outlet_Cd
                 AND AL.Principal_Map_Cd = 1
                 and al.dealer_type in ('S','2S','3S')
                 AND SH.VARIANT_CD = PA.DMS_VARIANT
                 
               GROUP BY ac.acc_code,
                        pa.model_code,
                        pa.model_variant_code,
                        sh.cancel_date)
       GROUP BY Row_Type,
                Item_code,
                Prefix,
                Bom_Item_Code,
                Bom_Prefix,
                Cluster_Code,
                Warehouse_Grp_Cd,
                Causal_Factor,
                Casual_Factor_Weight,
                As_on_date)''')
				
df.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/SP_VEH_RET_IFP/") 				