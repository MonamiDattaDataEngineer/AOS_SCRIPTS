from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

PH_ITEM_FAIL_PROFILE = spark.read.format('parquet').load("s3:/msil-aos-procesed/PH_ITEM_FAIL_PROFILE")
PH_ITEM_FAIL_PROFILE.createOrReplaceTempView("PH_ITEM_FAIL_PROFILE")


df = spark.sql('''(select distinct
       ph.Row_Type,
       ph.bom_item_code,
       '' Prefix,
       ph.cluster_code Warehouse_code,
       ph.Warehouse_Grp_Cd,
       ph.extraction_date Extraction_date,
       '' Description,
       ph.bom_item_code Master_Item_Code,
       '' Pref_Supp_cd,
       '' Activation_date,
       '' Deactivation_date,
       0 Unit_Cost,
       'INR' Unit_Cost_Curr,
       '' Replaced,
       '' Replace_desc,
       '' Buyer_code,
       '' Weight,
       '' Weight_unit_measure,
       '' Volume,
       '' Volume_unit_measure,
       '' Unit_of_measure,
       '' Pack_Size,
       '' Exc_from_redist,
       '' Active,
       '' Item_grp1,
       '' Item_grp2,
       '' Binning_Loc,
       '' Stock_multiple,
       '' Stock_override,
       '' Order_lvl_override,
       '' Order_lvl_logic,
       '' Buffer_Stk_override,
       '' Buffer_stk_logic,
       '' Free_Text1,
       '' Free_Text2,
       '' Free_Text3,
       '' Free_Text4,
       '' Free_Text5,
       '' Rotable_flag,
       '' Pref_workshop_cd,
       '' Max_stock,
       '' Alt_item_grp_cd,
       '' Image_URL,
       '' Pref_Ref_del_mod,
       '' Pref_On_Dmnd_del_mod,
       '' Pref_Risk_RunOut_del_mod,
       '' Pref_Cust_Del_Mod,
       '' Redist_Ord_Qty_Mul,
       '' Allow_mul_redist_src,
       '' Allow_Partial_redist_src,
       '' Allow_Partial_Redist
        from
        PH_ITEM_FAIL_PROFILE ph
      where ph.mean_cas_fail_l12m is not null and ph.mean_cas_fail_l12m <>0 )''')
	  
df.write.format('parquet').save(s3:/PH_VEH_FORCAST_ITEM)  