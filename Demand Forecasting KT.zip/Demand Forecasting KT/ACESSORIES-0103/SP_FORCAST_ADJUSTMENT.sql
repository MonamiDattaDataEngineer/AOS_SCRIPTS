from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

PH_AVG_QTY_IFP = spark.read.parquet("s3://msil-aos-processed/MULDMS.PH_AVG_QTY_IFP/")
PH_AVG_QTY_IFP.createOrReplaceTempView("PH_AVG_QTY_IFP")


df = spark.sql('''(select ph.row_type,
             ph.item_code Item_Code,
             '' Prefix,
             ph.parent_group || '_' || ph.dealer_map_cd || '_' ||
             ph.loc_code warehouse_code,
             '' Warehouse_grp_cd,
             ---to_char(sysdate, 'yyyymm') Period,
			 DATE_FORMAT(CURRENT_DATE, 'YYYYMM') Period,
             'ADD' Forcast_adjust_type,
             DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS Extraction Date,
             'ABS' Adjust_value_type,
             sum(ph.sale_value) /
             (select sum(ph1.sale_value)
                from PH_AVG_QTY_IFP PH1
               where PH.ITEM_CODE = PH1.ITEM_CODE
                 and PH.ACC_CODE = PH1.ACC_CODE) Adjustment,
             '' Exclude_demand,
             '' Comments,
             '' Demand_Stream
        from PH_AVG_QTY_IFP ph
       group by ph.row_type,
                ph.item_code,
                ph.parent_group,
                ph.dealer_map_cd,
                ph.loc_code,
                ph.acc_code)''')
				
df.write.format('parquet').save()				