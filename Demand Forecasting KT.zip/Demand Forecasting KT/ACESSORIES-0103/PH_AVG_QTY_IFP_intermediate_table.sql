import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")



DF_PH_ISSUE = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PH_ISSUE/")
DF_PD_ISSUE = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PD_ISSUE/")
df_AM_DEALER_LOC = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_DEALER_LOC/")
DF_ACC_DEALER_CODE_MAP_CD = spark.read.parquet('s3://msil-aos-raw/qlik-data/MULDMS.AM_ACC_DEALER_CODE_MAP/')
DF_pm_part = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART/")
df_am_company_master = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_COMPANY_MASTER/")
DF_GM_CITY = 
DF_AM_LIST = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.AM_LIST/")
DF_PM_PART_GROUP = spark.read.parquet("s3://msil-aos-raw/qlik-data/MULDMS.PM_PART_GROUP/")
DF_GM_VIN =
DF_PM_ACC_WEB_VAR_MAP

DF_GM_CITY.createOrReplaceTempView("gm_city")
DF_ACC_DEALER_CODE_MAP_CD.createOrReplaceTempView("am_acc_dealer_code_map")
df_AM_DEALER_LOC.createOrReplaceTempView("AM_DEALER_LOC")
df_am_company_master.createOrReplaceTempView("am_company_master")
DF_PH_ISSUE.createOrReplaceTempView("PH_ISSUE")
DF_PD_ISSUE.createOrReplaceTempView("PD_ISSUE")
DF_pm_part.createOrReplaceTempView("pm_part")
DF_AM_LIST.createOrReplaceTempView("AM_LIST")
DF_PM_PART_GROUP.createOrReplaceTempView("pm_part_group")
DF_GM_VIN.createOrReplaceTempView("gm.vin")
DF_PM_ACC_WEB_VAR_MAP.createOrReplaceTempView("pm_acc_web_var_map")




df= spark.sql("""(SELECT Parent_group,
           Dealer_map_cd,
           Row_Type,
             Item_code,
             Prefix,
             replace(Bom_Item_Code, ' ', '-') Bom_Item_Code,
             Bom_Prefix,
             Cluster_Code,
             Warehouse_Grp_Cd,
             Causal_Factor,
             sum(SALE_VALUE),
             Casual_Factor_Weight,
             ACC_CODE,
             LOC_CODE,
             As_on_date
        FROM (select distinct 
								pd.parent_group,
								pd.dealer_map_cd,
								'M' Row_Type,
								pm.part_num Item_Code,
								'' Prefix,
								pa.model_code || '-' || pa.model_variant_code Bom_Item_Code,
								'' Bom_Prefix,
								ac.acc_code Cluster_Code,
								'' Warehouse_Grp_Cd,
								'CAR_SALES' Causal_Factor,
								(round((Pd.Bill_Qty), 2)) SALE_VALUE,
								1 Casual_Factor_Weight,
								ac.acc_code,
								lo.loc_cd LOC_CODE,
								trunc(ph.doc_date) As_on_date,
								pd.ref_doc_num
                from ph_issue               ph,
                     pd_issue               pd,
                     am_dealer_loc          lo,
                     am_acc_dealer_code_map ac,
                     PM_PART                PM,
                     am_company_master      ma,
                     gm_city                gm,
                     am_list                al,
                     pm_part_group          pg,
                     gm_vin                 gv,
                     pm_acc_web_var_map     pa
               where Ph.DOC_TYPE IN ('RSI', 'CSI')
                 AND ph.parent_group = lo.parent_group
                 and ph.dealer_map_cd = lo.dealer_map_cd
                 and ph.loc_cd = lo.loc_cd
                 and ph.comp_fa = ma.comp_code
                 and (ph.doc_date) >= P_FROM_DATE
                 and (ph.doc_date) < P_TO_DATE
                 and ph.party_type NOT IN ('D', 'DI')
                 and pd.parent_group = ph.parent_group
                 and pd.dealer_map_cd = ph.dealer_map_cd
                 and pd.loc_cd = ph.loc_cd
                 and pd.comp_fa = ph.comp_fa
                 and pd.doc_type = ph.doc_type
                 and pd.doc_num = ph.doc_num
                 and pd.srl_num >= 0
                 AND PM.PART_NUM = pd.PART_NUM
                 AND PM.DEALER_MAP_CD = 1
                 AND PM.CATG_CD in ('AA')
                 AND AL.LIST_NAME = 'PART_TYPE'
                 AND AL.PRINCIPAL_MAP_CD = 1
                 AND PG.PRINCIPAL_MAP_CD = 1
                 AND PG.GROUP_CD = AL.LIST_CODE
                 AND PG.PART_NUM = PM.PART_NUM
                 and ma.parent_group = lo.parent_group
                 and ma.dealer_map_cd = lo.dealer_map_cd
                 and lo.principal_map_cd = 1
                 AND lo.city_cd = GM.City_Cd
                 and lo.Principal_Map_Cd = gm.principal_map_cd
                 AND AC.DEALER_CD = lo.Mul_Dealer_Cd
                 AND AC.Outlet_Cd = lo.Outlet_Cd
                 AND ph.vin = gv.vin
                 and gv.variant_cd = pa.dms_variant
                 AND gv.principal_map_cd = 1
                 and lo.dealer_type in ('S','2S','3S')
                 ---and lo.parent_group = 'VARUN'
                 ---and lo.region_cd = 'T1'
                 ---and ac.acc_code = '1012'
                    --and pm.part_num = '990J0M82PS0-010'
                 ---and pa.model_code = 'SWIFT'
                 ---and pa.model_variant_code = 'V'
               )
                group by
                Parent_group,
				Dealer_map_cd,
				Row_Type,
                Row_Type,
				Item_code,
				Prefix,
				Bom_Item_Code,
				Bom_Prefix,
				Cluster_Code,
				Warehouse_Grp_Cd,
				Causal_Factor,
				Casual_Factor_Weight,
				ACC_CODE,
				LOC_CODE,
				As_on_date)
''')

df.write\
.option("header" , True)\
.mode("overwrite")\
.parquet("s3://msil-aos-processed/PH_AVG_QTY_IFP/")  			 
			 