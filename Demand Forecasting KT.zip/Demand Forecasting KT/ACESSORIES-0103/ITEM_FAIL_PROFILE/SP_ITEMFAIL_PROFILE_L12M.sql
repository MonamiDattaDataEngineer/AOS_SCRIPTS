import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from datetime import date,timedelta

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
jdbc_url4 = 'jdbc:oracle:thin:@10.212.67.185:1522/replicadms'

password2 = 'kpmgdms2023'   #'muldms#123''crmdps#123' 
username = 'KPMGDMS'        #'MULDMS''CRMDPS'
connection_details = {"user": username, "password": password2 }


spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", True)
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",True)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled",True)
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
spark.conf.set("spark.sql.broadcastTimeout","6000")

PH_AVG_QTY_IFP = spark.read.parquet("s3://msil-aos-processed/MULDMS.PH_AVG_QTY_IFP/")
PH_AVG_QTY_IFP.createOrReplaceTempView("PH_AVG_QTY_IFP")
PH_VEH_RET_IFP = spark.read.format('parquet').load(""s3://msil-aos-processed/MULDMS.PH_VEH_RET_IFP/")
PH_VEH_RET_IFP.createOrReplaceTempView("PH_VEH_RET_IFP")


df3 = spark.sql('''(SELECT Row_Type,
             Item_code,
             Prefix,
             Bom_Item_Code,
             Bom_Prefix,
             Cluster_Code,
             Warehouse_Grp_Cd,
             Extraction_date,
             Causal_Factor,
             case
               when Penetration = 0 then
                0
               else
                1 / (Penetration)
             end as Mean_Cas_fail_L12M,
             Casual_Factor_Weight
        FROM (SELECT Row_Type,
                     Item_code,
                     Prefix,
                     Bom_Item_Code,
                     Bom_Prefix,
                     Cluster_Code,
                     Warehouse_Grp_Cd,
                     Extraction_date,
                     Causal_Factor,
                     Penetration,
                     Casual_Factor_Weight
                from (select a.row_type Row_Type,
                             a.item_code Item_code,
                             a.prefix Prefix,
                             a.bom_Item_code Bom_Item_Code,
                             a.bom_prefix Bom_Prefix,
                             a.cluster_code Cluster_Code,
                             a.warehouse_grp_cd Warehouse_Grp_Cd,
                             a.Extraction_date Extraction_date,
                             a.Causal_factor Causal_Factor,
                             case
                               when b.veh_retail = 0 then
                                0
                               else
                                a.sale_value / b.veh_retail
                             end as penetration,
                             a.Casual_factor_Weight
                        from (select ph.row_type,
                                     ph.item_code,
                                     ph.prefix,
                                     ph.bom_item_code,
                                     ph.bom_prefix,
                                     ph.cluster_code,
                                     ph.warehouse_grp_cd,
                                     DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS Extraction Date,
                                     ph.causal_factor,
                                     sum(ph.sale_value) SALE_VALUE,
                                     ph.casual_factor_weight
                                from PH_AVG_QTY_IFP ph
                               where as_on_date >= P_FROM_DATE
                                 and as_on_date < P_TO_DATE
                               group by ph.row_type,
                                        ph.item_code,
                                        ph.prefix,
                                        ph.bom_item_code,
                                        ph.bom_prefix,
                                        ph.cluster_code,
                                        ph.warehouse_grp_cd,
                                        ph.causal_factor,
                                        ph.casual_factor_weight) a,
                             (select pv.row_type,
                                     pv.item_code,
                                     pv.prefix,
                                     pv.bom_item_code,
                                     pv.bom_prefix,
                                     pv.cluster_code,
                                     pv.warehouse_grp_cd,
                                     DATE_FORMAT(CURRENT_TIMESTAMP(), "yyyyMMdd'T'HHmm") AS Extraction Date,
                                     pv.causal_factor,
                                     sum(pv.veh_retail) VEH_RETAIL,
                                     pv.casual_factor_weight
                                from PH_VEH_RET_IFP pv
                               where as_on_date >= P_FROM_DATE
                                 and as_on_date < P_TO_DATE
                               group by pv.row_type,
                                        pv.item_code,
                                        pv.prefix,
                                        pv.bom_item_code,
                                        pv.bom_prefix,
                                        pv.cluster_code,
                                        pv.warehouse_grp_cd,
                                        pv.causal_factor,
                                        pv.casual_factor_weight) b
                       where a.bom_item_code = b.bom_item_code
                         and a.cluster_code = b.cluster_code)''')
						 
df.write.option().format('parquet').save()						 